"use strict";
(() => {
const api = window.api;
let S = null, CAT = null, page = 'dashboard', live = [], scope = 'global', query = '', audio = null;

// ---------- tiny DOM toolkit ----------
function h(tag, props, ...kids) {
    const n = document.createElement(tag);
    if (props) for (const [k, v] of Object.entries(props)) {
        if (v == null || v === false) continue;
        if (k === 'class') n.className = v; else if (k === 'text') n.textContent = v; else if (k === 'html') n.innerHTML = v;
        else if (k === 'style') n.style.cssText = v; else if (k.startsWith('on')) n.addEventListener(k.slice(2), v); else n[k] = v;
    }
    const add = c => { if (c == null || c === false) return; if (Array.isArray(c)) c.forEach(add); else n.append(c.nodeType ? c : document.createTextNode(String(c))); };
    kids.forEach(add); return n;
}
const P = {
    dashboard: '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
    biomes: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
    channels: '<path d="M5 9h14M5 15h14M10 3 8 21M16 3l-2 18"/>',
    rules: '<path d="M4 6h9M17 6h3M4 12h3M11 12h9M4 18h11M19 18h1"/><circle cx="15" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="17" cy="18" r="2"/>',
    alerts: '<path d="M6 9a6 6 0 0 1 12 0c0 6 2 7 2 7H4s2-1 2-7"/><path d="M10 20a2 2 0 0 0 4 0"/>',
    activity: '<path d="M3 12h4l3-8 4 16 3-8h4"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>',
    power: '<path d="M12 3v9"/><path d="M6.3 6.3a8 8 0 1 0 11.4 0"/>', lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
    zap: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>', search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
    shop: '<path d="M4 7h16l-1 4a3 3 0 0 1-6 0 3 3 0 0 1-6 0zM5 11v9h14v-9"/>', plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>', ext: '<path d="M14 4h6v6M20 4l-9 9M18 14v6H4V6h6"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.2"/>', inbox: '<path d="M3 13l3-8h12l3 8M3 13v6h18v-6M3 13h5l1 3h6l1-3h5"/>'
};
const ico = (n, s = 18) => h('span', { class: 'ico', html: `<svg viewBox="0 0 24 24" width="${s}" height="${s}" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${P[n] || ''}</svg>` });

const fmtTime = t => new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
const mmss = ms => { const s = Math.ceil(ms / 1000); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
const tierOf = p => p >= 90 ? ['Mythic', 't4'] : p >= 70 ? ['Rare', 't3'] : p >= 40 ? ['Event', 't2'] : p > 0 ? ['Common', 't1'] : ['Any link', 't1'];
const GROUP_NAMES = { main: 'Main biomes', rare: 'Rare biomes', event: 'Event biomes', boss: 'Boss auras', merchants: 'Merchants', special: 'Special targets' };

function toast(text, kind = 'ok') {
    const t = h('div', { class: 'toast ' + kind }, h('div', { text }));
    $('#toasts').append(t); setTimeout(() => t.remove(), 3800);
}
const $ = (s, r = document) => r.querySelector(s);

// ---------- reusable controls ----------
function sw(value, onChange) {
    const b = h('button', { class: 'sw' + (value ? ' on' : ''), role: 'switch', onclick: () => { value = !value; b.classList.toggle('on', value); onChange(value); } });
    return b;
}
function seg(options, value, onChange) {
    const box = h('div', { class: 'seg' });
    for (const [v, label] of options) {
        const b = h('button', { class: v === value ? 'on' : '', text: label, onclick: () => { [...box.children].forEach(c => c.classList.toggle('on', c === b)); onChange(v); } });
        box.append(b);
    }
    return box;
}
function sel(options, value, onChange) {
    const s = h('select', { class: 'sel', onchange: () => onChange(options.find(o => String(o[0]) === s.value)[0]) },
        options.map(([v, label]) => h('option', { value: String(v), text: label })));
    s.value = String(value); return s;
}
const row = (title, desc, control) => h('div', { class: 'row' }, h('div', null, h('div', { class: 't', text: title }), desc && h('div', { class: 'd', text: desc })), control);
const card = (title, sub, ...kids) => h('div', { class: 'card' }, title && h('h2', null, title), sub && h('div', { class: 'sub', text: sub }), ...kids);
const head = (title, sub, right) => h('div', { class: 'ph' }, h('div', null, h('h1', { text: title }), h('p', { text: sub })), right);

function tags(list, onChange, placeholder) {
    const box = h('div'), chips = h('div', { class: 'tags' });
    const draw = () => chips.replaceChildren(...list.map(w => h('span', { class: 'tag' }, w, h('b', { text: '×', title: 'Remove', onclick: () => { list = list.filter(x => x !== w); onChange(list); draw(); } }))));
    const input = h('input', {
        class: 'in', placeholder,
        onkeydown: e => { if (e.key === 'Enter' && input.value.trim()) { const v = input.value.trim().toLowerCase(); if (!list.includes(v)) { list = [...list, v]; onChange(list); draw(); } input.value = ''; } }
    });
    box.append(input, chips); draw(); return box;
}

// A live region re-renders only when its key changes, so hover/focus is never disturbed.
function region(keyFn, build, cls) {
    const el = h('div', { class: cls }); let last = null;
    const r = { update() { const k = keyFn(S); if (k !== last) { last = k; el.replaceChildren(...[].concat(build(S)).filter(Boolean)); } } };
    el.update = () => r.update();
    live.push(r); r.update(); return el;
}

const set = async patch => { S = await api.patch(patch); tick(); };

// ---------- pages ----------
function dashboard() {
    const root = h('div');
    root.append(head('Dashboard', 'Real-time overview of your sniper.'));

    root.append(h('div', { class: 'card hero', style: 'margin-bottom:16px' }, region(
        s => [s.settings.enabled, s.watchers.filter(w => w.state === 'live').length, s.watchers.filter(w => w.enabled).length, s.watchers.some(w => w.state === 'login'), s.lock.left > 0, s.hasLast].join(),
        s => {
            const on = s.settings.enabled, enabled = s.watchers.filter(w => w.enabled), liveN = enabled.filter(w => w.state === 'live').length;
            const need = enabled.some(w => w.state === 'login');
            const sub = !s.watchers.length ? 'Add a Discord channel to start watching.' : need ? 'Sign in to Discord in the window that opened to start.' : `${liveN} of ${enabled.length} channel${enabled.length === 1 ? '' : 's'} live`;
            return h('div', { class: 'heroin' },
                h('button', { class: 'power' + (on ? ' on' : ''), title: 'Toggle sniper', onclick: () => set({ enabled: !on }) }, ico('power', 38)),
                h('div', null, h('h2', { text: on ? 'Sniper is active' : 'Sniper is paused' }), h('p', { text: sub })),
                h('div', { class: 'acts' },
                    !s.watchers.length && h('button', { class: 'btn pri', onclick: () => go('channels') }, ico('plus', 16), 'Add channel'),
                    s.lock.left > 0 && h('button', { class: 'btn', onclick: () => api.releaseLock() }, ico('lock', 16), 'Release lock'),
                    h('button', { class: 'btn', disabled: !s.hasLast, onclick: () => api.openLast() }, ico('zap', 16), 'Open last link')));
        }, 'heroin-wrap')));

    root.append(region(s => JSON.stringify(s.stats), s => {
        const st = s.stats;
        const tile = (icon, k, v, unit, n) => h('div', { class: 'card stat' }, h('div', { class: 'k' }, ico(icon, 15), k), h('div', { class: 'v' }, v, unit && h('small', { text: unit })), h('div', { class: 'n', text: n }));
        return [
            tile('zap', 'Launches today', st.today, '', st.total + ' all time'),
            tile('clock', 'Avg. reaction', st.avgMs == null ? '—' : st.avgMs, st.avgMs == null ? '' : 'ms', 'detect → launch call'),
            tile('target', 'Best reaction', st.bestMs == null ? '—' : st.bestMs, st.bestMs == null ? '' : 'ms', 'last 50 launches'),
            tile('eye', 'Links scanned', st.scanned, '', 'uptime ' + (st.uptimeSec >= 3600 ? Math.floor(st.uptimeSec / 3600) + 'h ' : '') + Math.floor(st.uptimeSec % 3600 / 60) + 'm')
        ];
    }, 'grid g4'));

    root.append(h('div', { class: 'grid g21' },
        card('Latest launch', null, region(s => JSON.stringify(s.last), s => {
            const l = s.last;
            if (!l) return h('div', { class: 'empty' }, ico('zap', 26), 'No launches yet. Your next hit will show up here.');
            const max = Math.max(l.totalMs, 1);
            const bar = (k, v) => h('div', { class: 'bar' }, h('span', { text: k }), h('i', { style: `--w:${Math.max(3, Math.min(100, v / max * 100))}%` }), h('span', { text: v + ' ms' }));
            return [h('div', { class: 'inline', style: 'justify-content:space-between' },
                h('div', null, h('div', { class: 'big', text: (l.merchant ? '🛒 ' : '') + l.target }), h('div', { class: 'note', style: 'margin:2px 0 0', text: `${l.watcher} · message was ${l.ageSec}s old · ${fmtTime(l.t)}` })),
                h('div', { style: 'text-align:right' }, h('div', { class: 'big', text: l.totalMs }), h('div', { class: 'note', style: 'margin:0', text: 'ms total' }))),
                h('div', { class: 'bars' }, bar('Detection', l.procMs), bar('Hand-off', l.ipcMs), bar('Launch call', l.launchMs))];
        })),
        card('Join lock', 'Blocks new launches while you are in a server.', region(s => Math.ceil(s.lock.left / 1000) + '|' + s.lock.total + '|' + s.lock.pausedLeft, s => {
            const left = s.lock.left, total = Math.max(1, s.lock.total), locked = left > 0;
            return h('div', { class: 'ringwrap' },
                h('div', { class: 'ring' + (locked ? '' : ' free'), style: `--p:${locked ? left / total * 100 : 0}` }, h('div', null, h('b', { text: locked ? mmss(left) : 'Free' }), h('small', { text: locked ? 'remaining' : 'ready to snipe' }))),
                h('div', { style: 'flex:1' },
                    h('button', { class: 'btn', style: 'width:100%;justify-content:center', disabled: !locked, onclick: () => api.releaseLock() }, ico('lock', 16), 'Release lock now'),
                    s.lock.pausedLeft > 0 && h('div', { class: 'err', text: 'Spam guard paused for ' + mmss(s.lock.pausedLeft) }),
                    h('div', { class: 'note', html: 'Shortcut <span class="kbd">Ctrl</span> <span class="kbd">Alt</span> <span class="kbd">L</span>' })));
        }))));

    root.append(h('div', { class: 'grid g2' },
        card('Channels', null, region(s => JSON.stringify(s.watchers.map(w => [w.id, w.label, w.state, w.lastMutationAgo == null ? '' : w.lastMutationAgo < 10 ? 'a' : w.lastMutationAgo < 60 ? 'b' : 'c'])), s => {
            if (!s.watchers.length) return h('div', { class: 'empty' }, ico('channels', 26), 'No channels yet.', h('div', null, h('button', { class: 'btn pri sm', style: 'margin-top:10px', onclick: () => go('channels') }, 'Add your first channel')));
            return h('div', { class: 'feed' }, s.watchers.map(w => h('div', { class: 'fi' }, h('span', { class: 'dot ' + w.state }), h('span', { class: 'tx', text: w.label }),
                h('time', { text: { live: 'live', loading: 'loading…', starting: 'starting…', login: 'sign-in needed', off: 'disabled' }[w.state] }))));
        })),
        card('Live activity', null, region(s => s.feed.map(f => f.id).join(), s => feedList(s.feed.slice(0, 8))))));
    return root;
}

function feedList(items) {
    if (!items.length) return h('div', { class: 'empty' }, ico('inbox', 26), 'Nothing yet. Matches, holds and blocks appear here.');
    return h('div', { class: 'feed' }, items.map(f => h('div', { class: 'fi' }, h('span', { class: 'dot ' + f.kind }), h('span', { class: 'tx', title: f.text, text: f.text }),
        f.canOpen && h('button', { class: 'btn sm', title: 'Release the lock and open this link', onclick: () => api.openFeed(f.id) }, 'Open'), h('time', { text: fmtTime(f.t) }))));
}

// --- biomes ---
const scopeSel = () => scope === 'global' ? S.settings.selection : (S.watchers.find(w => w.id === scope) || {}).sel || S.settings.selection;
const scopeCustom = () => scope === 'global' ? S.settings.custom : (S.watchers.find(w => w.id === scope) || {}).custom || S.settings.custom;
const saveSel = sel => scope === 'global' ? set({ selection: sel }) : api.updateWatcher({ id: scope, sel }).then(s => { S = s; tick(); });
const saveCustom = c => scope === 'global' ? set({ custom: c }) : api.updateWatcher({ id: scope, custom: c }).then(s => { S = s; tick(); });

function biomes() {
    const root = h('div');
    const scopes = [['global', 'Global defaults'], ...S.watchers.map(w => [w.id, w.label])];
    if (!scopes.some(s => s[0] === scope)) scope = 'global';
    root.append(head('Biomes & targets', 'Choose what to open. Each channel can use its own list.',
        sel(scopes, scope, v => { scope = v; go('biomes'); })));

    const bar = h('div', { class: 'toolbar' },
        h('div', { class: 'search' }, ico('search', 16), h('input', { class: 'in', placeholder: 'Search biomes, merchants…', value: query, oninput: e => { query = e.target.value; grid.update(); } })),
        CAT.presets.map(p => h('button', { class: 'chip', text: p.name, onclick: () => saveSel(p.ids) })));
    root.append(bar);
    root.append(region(() => scope + S.watchers.map(w => w.id + (w.sel ? '*' : '')).join(), () => scope !== 'global' && (S.watchers.find(w => w.id === scope) || {}).sel
        ? h('div', { class: 'note', style: 'margin:4px 0 0' }, 'This channel uses its own list. ', h('a', { href: '#', style: 'color:var(--accent2)', text: 'Reset to global defaults', onclick: e => { e.preventDefault(); api.updateWatcher({ id: scope, clearProfile: true }).then(s => { S = s; go('biomes'); }); } }))
        : scope !== 'global' ? h('div', { class: 'note', style: 'margin:4px 0 0', text: 'Following global defaults. Change anything to give this channel its own list.' }) : null));

    const grid = region(() => scopeSel().join() + '|' + query + '|' + scope, () => {
        const on = new Set(scopeSel()), q = query.trim().toLowerCase();
        const out = [];
        for (const g of CAT.groups) {
            const items = CAT.biomes.filter(b => b.g === g.id && (!q || b.name.toLowerCase().includes(q)));
            if (!items.length) continue;
            out.push(h('div', { class: 'sec', text: GROUP_NAMES[g.id] || g.title }), h('div', { class: 'bgrid' }, items.map(b => {
                const [tn, tc] = tierOf(b.pri);
                return h('div', { class: 'bc' + (on.has(b.id) ? ' on' : ''), onclick: () => { const n = new Set(scopeSel()); n.has(b.id) ? n.delete(b.id) : n.add(b.id); saveSel([...n]); } },
                    h('span', { class: 'ck' }), h('span', { class: 'nm', text: b.name }), b.merchant && ico('shop', 15), h('span', { class: 'tier ' + tc, text: tn }));
            })));
        }
        return out.length ? out : h('div', { class: 'empty' }, 'No matches for “' + query + '”.');
    });
    root.append(grid);

    root.append(h('div', { class: 'sec', text: 'Custom words' }), card(null, null,
        h('div', { class: 'note', style: 'margin:0 0 10px', text: 'Extra exact words or phrases that should trigger a launch (for example a specific aura name).' }),
        region(() => scopeCustom().join() + scope, () => tags(scopeCustom().slice(), saveCustom, 'Type a word or phrase and press Enter'))));
    return root;
}

// --- channels ---
function channels() {
    const root = h('div');
    root.append(head('Channels', 'Where the sniper listens: 1 to 3 channels, each in its own background Discord window. Any of them can trigger the join lock.'));
    root.append(h('div', { class: 'grid g2' },
        card('Discord account', 'You sign in normally inside the app. Madness BiomeSniperX never asks for, reads or stores your token.',
            h('div', { class: 'inline' }, h('button', { class: 'btn pri', onclick: () => api.signIn() }, ico('ext', 16), 'Sign in to Discord'),
                h('span', { class: 'note', style: 'margin:0', text: 'Your login is remembered after the first time.' }))),
        card('Window mode', 'Discord windows can stay out of sight while they work.',
            seg([['hidden', 'Hidden'], ['minimized', 'Minimized'], ['visible', 'Visible']], S.settings.windowMode, v => set({ windowMode: v })),
            h('div', { class: 'note', text: 'Hidden is fastest and cleanest. Use Visible only if you want to watch the channel yourself.' }))));

    const err = h('div', { class: 'err' });
    const url = h('input', { class: 'in', placeholder: 'Channel link, or: serverID channelID' });
    const label = h('input', { class: 'in', placeholder: 'Label (optional)', style: 'max-width:200px' });
    const add = async () => {
        const r = await api.addWatcher({ input: url.value, label: label.value });
        if (r.error) { err.textContent = r.error; return; }
        err.textContent = ''; url.value = ''; label.value = ''; S = await api.state(); tick(); toast('Channel added. Sign in if Discord asks you to.');
    };
    url.addEventListener('keydown', e => { if (e.key === 'Enter') add(); });
    root.append(card('Add a channel', 'Right-click the channel → Copy Link. With Developer Mode on you can also type: serverID channelID. A channel ID alone is not enough.',
        h('div', { class: 'inline' }, url, label, h('button', { class: 'btn pri', onclick: add }, ico('plus', 16), 'Add')), err));

    root.append(h('div', { style: 'height:16px' }), card('Watched channels', null, region(
        s => JSON.stringify(s.watchers.map(w => [w.id, w.label, w.enabled, w.state, w.windowVisible, w.hasProfile])),
        s => {
            if (!s.watchers.length) return h('div', { class: 'empty' }, ico('channels', 26), 'No channels yet. Add one above.');
            const names = { live: 'Live', loading: 'Loading…', starting: 'Starting…', login: 'Sign-in needed', off: 'Disabled' };
            return s.watchers.map(w => h('div', { class: 'wrow' }, h('span', { class: 'dot ' + w.state }),
                h('div', { class: 'meta' }, h('b', { text: w.label }), h('small', { text: `${names[w.state]} · channel ${w.channelId}${w.hasProfile ? ' · custom list' : ''}` })),
                h('input', { class: 'in', value: w.label, title: 'Rename', onchange: e => api.updateWatcher({ id: w.id, label: e.target.value }).then(x => { S = x; tick(); }) }),
                h('button', { class: 'btn sm', onclick: () => api.openWindow(w.id) }, ico('eye', 14), 'Show window'),
                sw(w.enabled, v => api.updateWatcher({ id: w.id, enabled: v }).then(x => { S = x; tick(); })),
                h('button', { class: 'btn sm danger', title: 'Remove', onclick: () => api.removeWatcher(w.id).then(x => { S = x; tick(); }) }, ico('trash', 14))));
        })));
    return root;
}

// --- rules ---
function rules() {
    const R = S.settings.rules, root = h('div');
    const setR = (k, v) => set({ rules: { [k]: v } });
    root.append(head('Rules', 'Safety, freshness and detection behaviour.'));
    root.append(h('div', { class: 'grid g2' },
        card('Safety', null,
            row('Join lock', 'After a launch, ignore new links for this long. You can always release it manually.', sel([[0, 'Off'], [30000, '30 seconds'], [60000, '1 minute'], [120000, '2 minutes'], [300000, '5 minutes'], [600000, '10 minutes']], R.joinLockMs, v => setR('joinLockMs', v))),
            row('Open only the rarest', 'If several links arrive together, launch only the highest-priority one.', sw(R.priorityPick, v => setR('priorityPick', v))),
            row('Rare biomes override lock', 'Mythic-tier targets may launch even while the join lock is active.', sw(R.bypassLockRare, v => setR('bypassLockRare', v))),
            row('Spam guard', 'Pause for 30 s after 4 launches within 20 s (flood protection).', sw(R.spamGuard, v => setR('spamGuard', v)))),
        card('Freshness', 'Only brand-new messages are ever read.',
            row('Maximum message age', 'Messages older than this are ignored, even if they appear late.', sel([[0, 'Off'], [5, '5 seconds'], [10, '10 seconds'], [15, '15 seconds'], [30, '30 seconds'], [60, '60 seconds']], R.maxAgeSec, v => setR('maxAgeSec', v))),
            row('Wait after opening a channel', 'Everything on screen at that moment counts as old.', sel([[150, '0.15 s'], [400, '0.4 s'], [700, '0.7 s'], [1000, '1 s']], R.settleMs, v => setR('settleMs', v)))),
        card('Detection', null,
            row('Typo tolerance', 'Strict = exact words only. Aggressive catches heavy typos but may misfire.', seg([['strict', 'Strict'], ['balanced', 'Balanced'], ['aggressive', 'Aggressive']], R.typoMode, v => setR('typoMode', v))),
            row('Context awareness', 'Understands “not here”, “ended”, “dont miss”… without any online AI.', sw(R.contextAI, v => setR('contextAI', v))),
            row('Bot embeds & Join buttons', 'Reads bot posts like “BIOME STARTED – GLITCHED Found” and opens the Roblox link behind their Join button.', sw(R.scanEmbeds, v => setR('scanEmbeds', v))),
            row('Pair split messages', 'If a bot announces a biome first and posts the Join link in a second message a moment later (either order), connect the two.', sw(R.pairSplit, v => setR('pairSplit', v))),
            row('Pairing window', 'How long the two messages may be apart.', sel([[5, '5 seconds'], [10, '10 seconds'], [20, '20 seconds'], [30, '30 seconds']], R.pairWindowSec, v => setR('pairWindowSec', v)))),
        card('Filters', null,
            h('div', { class: 't', text: 'Blocked users' }), tags(R.blockUsers.slice(), v => setR('blockUsers', v), 'Name (or part of it) + Enter'),
            h('div', { class: 't', style: 'margin-top:16px', text: 'Trusted users only' }), h('div', { class: 'd note', style: 'margin:0', text: 'If you add anyone here, only they can trigger a launch.' }), tags(R.allowUsers.slice(), v => setR('allowUsers', v), 'Name + Enter'),
            h('div', { class: 't', style: 'margin-top:16px', text: 'Extra cancel words' }), tags(R.extraIgnore.slice(), v => setR('extraIgnore', v), 'e.g. cancelled, patched'))));

    const out = h('div', { class: 'tags' }), input = h('input', { class: 'in', placeholder: 'Try: singu · dont miss glitch · not cyber · jester has not arrived' });
    let timer = null;
    input.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(async () => {
        if (!input.value.trim()) { out.replaceChildren(); return; }
        const r = await api.test({ text: input.value, wid: scope === 'global' ? null : scope });
        out.replaceChildren(r.snipe ? h('span', { class: 'tag okc', text: '✓ Would open: ' + r.word }) : r.hits.length
            ? h('span', { class: 'tag', style: 'color:#fca5a5', text: '⛔ Blocked: ' + r.hits.map(x => x.why).filter(Boolean).join('; ') }) : h('span', { class: 'tag', text: 'No match for the selected targets' }));
    }, 120); });
    root.append(card('Message tester', 'Type a message to see exactly what the sniper would do with it, using your current selection.', input, out));
    return root;
}

// --- alerts ---
function playTone(tier) {
    const A = S.settings.alerts;
    if (A.sound) {
        try {
            audio = audio || new AudioContext(); if (audio.state === 'suspended') audio.resume();
            const tones = tier >= 90 ? [880, 1175, 1568] : tier >= 50 ? [880, 1175] : [740];
            tones.forEach((f, i) => { const o = audio.createOscillator(), g = audio.createGain(), t = audio.currentTime + i * 0.11; o.frequency.value = f; g.gain.value = A.volume / 100 * 0.18; o.connect(g); g.connect(audio.destination); o.start(t); o.stop(t + 0.09); });
        } catch (_) {}
    }
}
function alerts() {
    const A = S.settings.alerts, root = h('div');
    const setA = (k, v) => set({ alerts: { [k]: v } });
    root.append(head('Alerts', 'How the app tells you something was launched.'));
    const status = h('div', { class: 'note', text: S.webhookStatus || '' });
    const hook = h('input', { class: 'in', type: 'password', placeholder: A.webhookSet ? 'Saved. Paste a new URL to replace it.' : 'https://discord.com/api/webhooks/…', autocomplete: 'off' });
    root.append(h('div', { class: 'grid g2' },
        card('Sound & voice', null,
            row('Sound', 'A short tone whenever a launch happens.', sw(A.sound, v => setA('sound', v))),
            row('Volume', null, h('div', { class: 'inline' }, h('input', { type: 'range', min: 0, max: 100, value: A.volume, onchange: e => setA('volume', Number(e.target.value)) }), h('button', { class: 'btn sm', onclick: () => playTone(95) }, 'Test'))),
            row('Voice', 'Speaks the biome name out loud.', sw(A.voice, v => setA('voice', v))),
            row('Desktop notifications', 'A Windows notification with the reaction time.', sw(A.notify, v => setA('notify', v)))),
        card('Discord webhook', 'Optional: post a rich report to a channel you own. Links and user names are never included.',
            row('Send reports', null, sw(A.webhookEnabled, v => setA('webhookEnabled', v))),
            h('div', { style: 'margin-top:12px' }, hook),
            h('div', { class: 'inline', style: 'margin-top:10px' },
                h('button', { class: 'btn pri sm', onclick: async () => { if (hook.value.trim()) { await set({ alerts: { webhookUrl: hook.value.trim() } }); hook.value = ''; toast('Webhook saved'); } } }, 'Save URL'),
                h('button', { class: 'btn sm', onclick: async () => { status.textContent = 'Sending…'; status.textContent = await api.testWebhook(); } }, 'Send test')), status)));
    return root;
}

// --- activity ---
function activity() {
    const root = h('div'), body = h('div');
    const load = async () => {
        const rows = await api.history();
        body.replaceChildren(rows.length ? h('table', { class: 'tbl' }, h('thead', null, h('tr', null, ['Time', 'Target', 'Channel', 'User', 'Msg age', 'Reaction'].map(t => h('th', { text: t })))),
            h('tbody', null, rows.map(r => h('tr', null, h('td', { text: new Date(r.t).toLocaleString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', day: 'numeric', month: 'short' }) }),
                h('td', { text: (r.merchant ? '🛒 ' : '') + r.target }), h('td', { text: r.watcher }), h('td', { text: r.user || '—' }), h('td', { text: r.ageSec + ' s' }), h('td', { text: r.totalMs + ' ms' })))))
            : h('div', { class: 'empty' }, ico('inbox', 26), 'No launches recorded yet.'));
    };
    root.append(head('Activity', 'Launch history and the live event stream.', h('button', { class: 'btn danger', onclick: async () => { await api.clearHistory(); load(); toast('History cleared'); } }, ico('trash', 15), 'Clear history')));
    root.append(card('Launch history', null, body), h('div', { style: 'height:16px' }), card('Live events', null, region(s => s.feed.map(f => f.id).join(), s => feedList(s.feed))));
    root.refresh = load; load(); return root;
}

// --- settings ---
function settingsPage() {
    const A = S.settings.app, root = h('div');
    const setApp = (k, v) => set({ app: { [k]: v } });
    const out = h('textarea', { class: 'ta', placeholder: 'Diagnostics and settings JSON appear here.' }), msg = h('div', { class: 'note' });
    root.append(head('Settings', 'App behaviour and maintenance.'));
    root.append(h('div', { class: 'grid g2' },
        card('Application', null,
            row('Start with Windows', 'Launch quietly in the tray when you sign in.', sw(A.openAtLogin, v => setApp('openAtLogin', v))),
            row('Keep running in the tray', 'Closing the window keeps the sniper working.', sw(A.closeToTray, v => setApp('closeToTray', v))),
            row('Start minimized', null, sw(A.startMinimized, v => setApp('startMinimized', v))),
            row('Global hotkeys', 'Ctrl+Alt+S toggle · Ctrl+Alt+L release lock · Ctrl+Alt+O open last link.', sw(A.hotkeys, v => setApp('hotkeys', v))),
            row('Accent colour', null, h('div', { class: 'swatches' }, [['indigo', '#6366f1'], ['emerald', '#10b981'], ['rose', '#f43f5e'], ['amber', '#f59e0b'], ['cyan', '#06b6d4']].map(([k, c]) =>
                h('div', { class: 'swatch' + (A.accent === k ? ' on' : ''), style: 'background:' + c, title: k, onclick: e => { [...e.target.parentNode.children].forEach(x => x.classList.remove('on')); e.target.classList.add('on'); setApp('accent', k); } }))))),
        card('Maintenance', null,
            h('div', { class: 'inline', style: 'flex-wrap:wrap' },
                h('button', { class: 'btn', onclick: async () => { const r = await api.selfTest(); msg.className = r.failed.length ? 'err' : 'note okc'; msg.textContent = r.failed.length ? `${r.passed}/${r.total} passed · failed: ${r.failed.join(', ')}` : `✓ ${r.total}/${r.total} engine tests passed`; } }, 'Run self-test'),
                h('button', { class: 'btn', onclick: async () => { const ok = await api.testLaunch(); msg.className = ok ? 'note okc' : 'err'; msg.textContent = ok ? '✓ Roblox handler responded' : 'Roblox is not installed or its protocol handler is missing.'; } }, 'Test Roblox launch'),
                h('button', { class: 'btn', onclick: async () => { out.value = await api.diagnostics(); try { await navigator.clipboard.writeText(out.value); msg.className = 'note okc'; msg.textContent = 'Diagnostics copied to clipboard.'; } catch (_) {} } }, 'Copy diagnostics')),
            msg, h('div', { style: 'margin-top:14px' }, out),
            h('div', { class: 'inline', style: 'margin-top:10px;flex-wrap:wrap' },
                h('button', { class: 'btn sm', onclick: async () => { out.value = await api.exportSettings(); msg.className = 'note'; msg.textContent = 'Settings exported above (webhook URL is never included).'; } }, 'Export settings'),
                h('button', { class: 'btn sm', onclick: async () => { const r = await api.importSettings(out.value); S = await api.state(); msg.className = r.error ? 'err' : 'note okc'; msg.textContent = r.error || '✓ Settings imported'; tick(); } }, 'Import settings'),
                h('button', { class: 'btn sm danger', onclick: async () => { if (confirm('Reset all settings to defaults? Channels are kept.')) { S = await api.resetSettings(); go('settings'); toast('Settings reset'); } } }, 'Reset to defaults'),
                h('button', { class: 'btn sm ghost', onclick: () => api.quit() }, 'Quit app')))));
    root.append(card('About', null, h('div', { class: 'note', style: 'margin:0', html: `Madness BiomeSniperX Desktop <b>v${S.version}</b>. Detection runs entirely on your PC and launches Roblox directly through the operating system: no browser, no tab, no extra prompt. The app only reads messages that Discord already shows in its own window; nothing is ever sent to Discord on your behalf.` })));
    return root;
}

// ---------- shell ----------
const PAGES = { dashboard, biomes, channels, rules, alerts, activity, settings: settingsPage };
const NAV = [['dashboard', 'Dashboard'], ['biomes', 'Biomes'], ['channels', 'Channels'], ['rules', 'Rules'], ['alerts', 'Alerts'], ['activity', 'Activity'], ['settings', 'Settings']];

function buildSide() {
    const side = $('#side');
    side.replaceChildren(
        h('div', { class: 'brand' }, h('div', { class: 'logo' }, ico('target', 20)), h('div', null, h('b', { text: 'BiomeSniperX' }), h('span', { text: 'Desktop · by Madness' }))),
        ...NAV.map(([id, label]) => h('button', { class: 'nav', id: 'nav-' + id, onclick: () => go(id) }, ico(id, 18), label, id === 'channels' ? h('span', { class: 'badge', id: 'nav-ch' }) : null)),
        h('div', { class: 'grow' }),
        h('div', { class: 'pill', id: 'pill' }, h('span', { class: 'dot', id: 'pdot' }), h('div', null, h('div', { id: 'ptxt' }), h('small', { id: 'psub' }))),
        h('div', { class: 'ver', id: 'ver' }));
}
function tickShell() {
    document.body.dataset.accent = S.settings.app.accent;
    const on = S.settings.enabled, live = S.watchers.filter(w => w.state === 'live').length;
    $('#pdot').className = 'dot ' + (on ? (live ? 'live' : 'loading') : '');
    $('#ptxt').textContent = on ? 'Sniper active' : 'Sniper paused';
    $('#psub').textContent = S.lock.left > 0 ? 'Join lock ' + mmss(S.lock.left) : S.watchers.length ? live + ' live · clock ' + S.clock.state : 'No channels yet';
    $('#nav-ch').textContent = S.watchers.length || '';
    $('#ver').textContent = 'v' + S.version + ' · ' + S.clock.state;
}
function tick() { if (!S) return; tickShell(); live.forEach(r => r.update()); }

function go(name) {
    page = name; live = [];
    NAV.forEach(([id]) => $('#nav-' + id).classList.toggle('on', id === name));
    const el = PAGES[name](); el.className = 'fade';
    $('#page').replaceChildren(el); $('#page').scrollTop = 0; $('#page').current = el; tick();
}

api.on('state', s => { S = s; tick(); });
api.on('launch', d => {
    playTone(d.pri || 95);
    if (S && S.settings.alerts.voice) { try { speechSynthesis.cancel(); speechSynthesis.speak(new SpeechSynthesisUtterance(d.target)); } catch (_) {} }
    toast('🚀 Launching ' + d.target);
    if (page === 'activity' && $('#page').current.refresh) $('#page').current.refresh();
});
api.on('held', d => toast(d.target + ' was held back by your safety rules. Open it from Live activity.', 'warn'));

Promise.all([api.catalog(), api.state()]).then(([c, s]) => { CAT = c; S = s; buildSide(); go('dashboard'); });
})();
