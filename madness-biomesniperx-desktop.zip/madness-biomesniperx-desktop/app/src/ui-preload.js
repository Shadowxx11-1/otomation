"use strict";
const { contextBridge, ipcRenderer } = require('electron');
const call = ch => (...a) => ipcRenderer.invoke(ch, ...a);
const EVENTS = new Set(['state', 'launch', 'held']);
contextBridge.exposeInMainWorld('api', {
    state: call('state:get'), catalog: call('catalog'), patch: call('settings:patch'),
    addWatcher: call('watcher:add'), updateWatcher: call('watcher:update'), removeWatcher: call('watcher:remove'),
    openWindow: call('window:open'), releaseLock: call('lock:release'), openFeed: call('feed:open'), openLast: call('last:open'),
    test: call('engine:test'), selfTest: call('selftest'), testLaunch: call('launch:test'), testWebhook: call('webhook:test'),
    history: call('history:get'), clearHistory: call('history:clear'), signIn: call('signin:open'), diagnostics: call('diagnostics'),
    exportSettings: call('settings:export'), importSettings: call('settings:import'), resetSettings: call('settings:reset'), quit: call('app:quit'),
    on: (channel, cb) => { if (EVENTS.has(channel)) ipcRenderer.on(channel, (_e, data) => cb(data)); }
});
