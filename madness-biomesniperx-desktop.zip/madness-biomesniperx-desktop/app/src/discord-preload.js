"use strict";
// Runs inside every Discord window (isolated world). It only READS the messages Discord already renders,
// finds new Roblox links, and reports candidates to the main process, which launches Roblox.
// It exposes nothing to the page and never touches Discord's token or network traffic.
const { ipcRenderer, webFrame } = require('electron');
const E = require('./engine');
const core = require('./core');

// Make Discord render normally even when the window is hidden or minimised.
try {
    webFrame.executeJavaScript(`(()=>{try{
        Object.defineProperty(document,'hidden',{configurable:true,get:()=>false});
        Object.defineProperty(document,'visibilityState',{configurable:true,get:()=>'visible'});
        document.addEventListener('visibilitychange',e=>e.stopImmediatePropagation(),true);
    }catch(e){}})();`);
} catch (_) {}

let cfg = null, analyzer = null, anyBiome = null;
const state = {
    channelId: null, guildId: null, ready: false, firstSeenAt: 0, baseline: 0n, baselineCount: 0,
    channelSince: Date.now(), lastMutationAt: 0, newLinks: 0, scanned: 0, lastPath: ''
};
let done = new Set(), texts = new Map(), pending = new Set();

const loggedIn = () => /^\/channels\//.test(location.pathname);
const channelOf = () => { const m = /^\/channels\/(?:@me|\d+)\/(\d+)/.exec(location.pathname); return m ? m[1] : null; };
const guildOf = () => { const m = /^\/channels\/(\d+)\/\d+/.exec(location.pathname); return m ? m[1] : null; };

function applyConfig(next) {
    cfg = next;
    analyzer = core.makeAnalyzer(cfg);
    // Knows every biome name (selected or not): a message that names ANY biome is a complete announcement, never a pairing partner.
    anyBiome = core.makeAnalyzer({ ...cfg, selection: E.BIOMES.map(b => b.id).filter(id => id !== 'link_only'), custom: [] });
    texts.clear();
    resetPairing();
}

// ---------- message parsing ----------
function parseLi(li) {
    const m = /^chat-messages-(?:(\d+)-)?(\d+)$/.exec(li.id);
    if (!m || m[2].length < 16) return null;
    try { return { channel: m[1] || null, id: BigInt(m[2]) }; } catch (_) { return null; }
}
const ageCheckOn = () => cfg && cfg.maxAgeSec > 0 && cfg.clockOk;
const ageSec = p => (Date.now() + cfg.skewMs - (Number(p.id >> 22n) + 1420070400000)) / 1000;

function findRobloxLink(root) {
    for (const a of root.querySelectorAll('a[href]')) {
        const proto = E.toRobloxProtocol(a.href, location.href);
        if (proto) return { proto };
    }
    return null;
}

function authorOf(li) {
    let node = li;
    for (let i = 0; i < 40 && node; i++) {
        const name = node.querySelector && (node.querySelector('h3 [id^="message-username-"]') || node.querySelector('[id^="message-username-"]'));
        if (name) return (name.textContent || '').trim();
        node = node.previousElementSibling;
    }
    return '';
}

const tidy = t => String(t || '').replace(/https?:\/\/\S+/gi, ' ').replace(/www\.roblox\.com\/\S*/gi, ' ').replace(/\b(?:www\.)?roblox\.com\b/gi, ' ')
    .replace(/[\u200B-\u200F\uFEFF]/g, ' ').replace(/\s+/g, ' ').trim();

// Text of an embed area with a space between every text node, so adjacent blocks never fuse into one word ("SnowyFound").
function textOf(el) {
    if (!el) return '';
    const walker = document.createTreeWalker(el, 4);          // 4 = SHOW_TEXT
    const parts = []; let n;
    while ((n = walker.nextNode())) { const t = n.nodeValue && n.nodeValue.trim(); if (t) parts.push(t); }
    return parts.join(' ');
}

// Reads one message. Shapes understood:
//  1. a person's message with a Roblox link in the text (Discord's own preview card of that link is ignored);
//  2. a bot message whose embed + "Join" button / "Join" text link carry the Roblox link;
//  3. a bot message with embed text but no readable Roblox link yet (an announcement waiting for its link).
function readMessage(li) {
    const linkOnlyOn = cfg.selection.includes('link_only');
    const content = li.querySelector('[id^="message-content-"]');
    const acc = (cfg.scanEmbeds || linkOnlyOn) ? li.querySelector('[id^="message-accessories-"]') : null;
    if (!content && !acc) return null;

    const contentLink = content ? findRobloxLink(content) : null;
    const accLink = acc ? findRobloxLink(acc) : null;
    const isPreview = Boolean(contentLink && accLink && contentLink.proto === accLink.proto);   // Discord's unfurl of the user's own link
    const link = contentLink || accLink;

    const clone = content ? content.cloneNode(true) : null;
    if (clone) for (const a of clone.querySelectorAll('a[href]')) if (E.toRobloxProtocol(a.href, location.href)) a.remove();
    const caption = tidy(clone ? clone.textContent : '');

    let text = caption, botCard = false, hosts = [];
    if (cfg.scanEmbeds && acc && !isPreview) {
        // "Previous: Normal" names the biome that just ended, not the one that started.
        const embedText = tidy(textOf(acc).replace(/\bPrevious\b:?\s+[A-Z][\w']*(?:\s+[A-Z][\w']*)?/g, ' '));
        if (embedText) { text = (caption + ' ' + embedText).trim(); botCard = true; }
        if (botCard && !link) {
            hosts = [...new Set([...acc.querySelectorAll('a[href]')].map(a => { try { return new URL(a.href).hostname; } catch (_) { return ''; } })
                .filter(h => h && !/discord(?:app)?\.com$/i.test(h)))].slice(0, 3);
        }
    }
    if (!link && !botCard) return null;
    return { text, isLinkOnly: caption.length === 0 && !botCard, proto: link ? link.proto : null, botCard, hosts };
}

let lastEvt = 0;
function sendEvt(kind, text) {
    const now = Date.now();
    if (now - lastEvt < 200) return;               // never flood the main process
    lastEvt = now;
    ipcRenderer.send('w:evt', { kind, text: String(text).slice(0, 160) });
}

// ---------- split-message pairing: announcement (no link) + link message, in either order ----------
let annPending = [], linkPool = [];
const pairMs = () => Math.max(1, Number(cfg && cfg.pairWindowSec) || 10) * 1000;
const sameAuthor = (a, b) => Boolean(a && b && a === b);       // both authors must be known and equal
// Times below are the messages' own send times (from their ids), so re-reading an old message never makes it look fresh.
function prunePairing(serverNow) { const w = pairMs() + 1500; annPending = annPending.filter(a => serverNow - a.t <= w); linkPool = linkPool.filter(l => serverNow - l.t <= w); }
function resetPairing() { for (const a of annPending) clearTimeout(a.timer); annPending = []; linkPool = []; }

function evaluate(li) {
    const parsed = parseLi(li);
    if (!parsed) { done.add(li.id); return null; }
    if (parsed.channel && parsed.channel !== state.channelId) return null;
    if (parsed.id <= state.baseline) { done.add(li.id); return null; }
    const age = ageSec(parsed);
    if (ageCheckOn() && age > cfg.maxAgeSec) { done.add(li.id); return null; }

    const message = readMessage(li);
    if (!message) return null;
    const fingerprint = (message.proto || 'nolink') + '|' + message.text;
    if (texts.get(li.id) === fingerprint) return null;
    if (!texts.has(li.id) && message.proto) { state.newLinks++; state.scanned++; }
    texts.set(li.id, fingerprint);

    const now = Date.now();
    const ts = Number(parsed.id >> 22n) + 1420070400000;
    prunePairing(now + cfg.skewMs);
    const preview = message.text.replace(/\s+/g, ' ').trim().slice(0, 70) || '(link only)';
    const base = { msgId: String(parsed.id), ageSec: Math.round(age * 10) / 10, linkOnly: false };

    // 1) an announcement whose link is not here (yet)
    if (!message.proto) {
        const r = analyzer.analyze(message.text);
        if (!r.snipe) return null;
        const author = authorOf(li);
        if (!cfg.pairing) { sendEvt('nolink', r.word + ' matched in a bot message, but it has no Roblox link' + (message.hosts.length ? ' (its button points to ' + message.hosts.join(', ') + ')' : '')); return null; }
        for (let i = linkPool.length - 1; i >= 0; i--) {                      // the link message may already have arrived
            const l = linkPool[i];
            if (!sameAuthor(l.author, author) || Math.abs(l.t - ts) > pairMs()) continue;
            linkPool.splice(i, 1); done.add(li.id);
            return { ...base, proto: l.proto, word: r.word, pri: r.pri, merchant: r.merchant === true, preview: 'Paired · ' + preview, author: cfg.needAuthor ? author : null };
        }
        annPending = annPending.filter(a => a.liId !== li.id);
        const entry = { liId: li.id, word: r.word, pri: r.pri, merchant: r.merchant === true, author, t: ts, preview, timer: 0 };
        entry.timer = setTimeout(() => {
            if (!annPending.includes(entry)) return;
            annPending = annPending.filter(a => a !== entry);
            sendEvt('nolink', entry.word + ' was announced but no Roblox link followed within ' + Math.round(pairMs() / 1000) + 's');
        }, Math.max(300, pairMs() - Math.max(0, age * 1000)));
        annPending.push(entry);
        if (message.hosts.length) sendEvt('nolink', r.word + ' announced; its button points to ' + message.hosts.join(', ') + ' (waiting for a Roblox link)');
        return null;
    }

    // 2) a message that has a Roblox link
    for (const a of annPending) if (a.liId === li.id) clearTimeout(a.timer);
    annPending = annPending.filter(a => a.liId !== li.id);                    // same message edited to add its link
    let result = analyzer.analyze(message.text), linkOnly = false;
    if (!result.snipe && cfg.selection.includes('link_only') && message.isLinkOnly) { result = { snipe: true, word: 'Link only', pri: 0, hits: [] }; linkOnly = true; }
    if (result.snipe) {
        done.add(li.id);
        return { ...base, linkOnly, proto: message.proto, word: result.word, pri: result.pri, merchant: result.merchant === true,
            preview: linkOnly ? '(Roblox link only)' : preview, author: cfg.needAuthor ? authorOf(li) : null };
    }
    if (result.hits.length) { sendEvt('block', preview + ' → ' + result.hits.map(h => h.why).filter(Boolean).join('; ')); return null; }

    if (cfg.pairing && anyBiome.analyze(message.text).hits.length === 0) {    // a link with no biome words may complete a waiting announcement
        const author = authorOf(li);
        for (let i = annPending.length - 1; i >= 0; i--) {
            const a = annPending[i];
            if (!sameAuthor(a.author, author) || Math.abs(a.t - ts) > pairMs()) continue;
            clearTimeout(a.timer); annPending.splice(i, 1); done.add(li.id);
            return { ...base, proto: message.proto, word: a.word, pri: a.pri, merchant: a.merchant, preview: 'Paired · ' + a.preview, author: cfg.needAuthor ? author : null };
        }
        linkPool.push({ proto: message.proto, author, t: ts });
        if (linkPool.length > 12) linkPool.shift();
    }
    return null;
}

function sendBatch(items, t0) {
    if (!items.length) return;
    ipcRenderer.send('w:batch', { sentAt: Date.now(), procMs: performance.now() - t0, items, channelId: state.channelId, guildId: state.guildId });
}

function processPending(t0) {
    const list = [...pending]; pending = new Set();
    const items = [];
    for (const li of list) {
        if (!li.isConnected || done.has(li.id)) continue;
        const c = evaluate(li); if (c) items.push(c);
    }
    sendBatch(items, t0);
}

// ---------- baseline: whatever is on screen when a channel opens counts as old ----------
function establishBaseline(items, now) {
    let max = 0n, count = 0;
    for (const li of items) {
        const p = parseLi(li);
        if (!p || (p.channel && p.channel !== state.channelId)) continue;
        count++; if (p.id > max) max = p.id;
    }
    const settle = cfg.clockOk ? Math.min(cfg.settleMs, 150) : cfg.settleMs;
    if (count > 0 && !state.firstSeenAt) { state.firstSeenAt = now; setTimeout(safeScan, settle + 30); }
    if (count > 0 && now - state.firstSeenAt >= settle) { state.baseline = max; state.baselineCount = count; state.ready = true; }
    else if (count === 0 && now - state.channelSince >= 5000) {
        const cutoff = Math.max(0, Math.floor(now + cfg.skewMs - 1420070400000 - 3000));
        state.baseline = BigInt(cutoff) << 22n; state.ready = true;
    }
}

// Live-only: walk from the NEWEST message backwards and stop at the first one already known to be old.
function scan() {
    const t0 = performance.now();
    checkRoute();
    if (!cfg || !state.channelId) return;
    const items = document.querySelectorAll('li[id^="chat-messages-"]');
    if (!state.ready) { establishBaseline(items, Date.now()); return; }
    const found = [];
    for (let i = items.length - 1; i >= 0; i--) {
        const li = items[i];
        if (done.has(li.id)) continue;
        const p = parseLi(li);
        if (!p) continue;
        if (p.channel && p.channel !== state.channelId) continue;
        if (p.id <= state.baseline) break;
        if (ageCheckOn() && ageSec(p) > cfg.maxAgeSec) break;
        const c = evaluate(li); if (c) found.push(c);
    }
    sendBatch(found, t0);
    if (done.size > 6000) { const keep = [...done].slice(-3000); done = new Set(keep); }
    if (texts.size > 6000) texts.clear();
}
function safeScan() { try { scan(); } catch (e) { console.error('[Sniper] scan', e); } }

// ---------- route / channel tracking ----------
function checkRoute() {
    if (location.pathname === state.lastPath && state.channelId === channelOf()) return;
    state.lastPath = location.pathname;
    const id = channelOf();
    if (id !== state.channelId) {
        state.channelId = id; state.guildId = guildOf();
        state.ready = false; state.firstSeenAt = 0; state.baseline = 0n; state.baselineCount = 0; state.channelSince = Date.now();
        pending = new Set(); resetPairing();
    }
    ipcRenderer.send('w:ctx', { guildId: guildOf(), channelId: id, loggedIn: loggedIn() });
}

// ---------- fast path: MutationObserver ----------
function collect(node, bucket) {
    if (!node) return;
    const el = node.nodeType === 1 ? node : node.parentElement;
    if (!el) return;
    const li = el.closest ? el.closest('li[id^="chat-messages-"]') : null;
    if (li) { bucket.add(li); return; }
    if (node.nodeType === 1 && (node.tagName === 'OL' || node.tagName === 'UL' || node.tagName === 'DIV')) {
        node.querySelectorAll('li[id^="chat-messages-"]').forEach(x => bucket.add(x));
    }
}
function onMutations(records) {
    try {
        const t0 = performance.now();
        state.lastMutationAt = Date.now();
        if (!cfg) return;
        checkRoute();
        if (!state.channelId) return;
        if (!state.ready) { scan(); return; }
        const before = pending.size;
        for (const r of records) {
            if (r.type === 'characterData') { collect(r.target, pending); continue; }
            const inside = r.target && r.target.closest ? r.target.closest('li[id^="chat-messages-"]') : null;
            if (inside) pending.add(inside);
            for (const n of r.addedNodes) collect(n, pending);
        }
        if (pending.size > before) processPending(t0);      // same JS turn as Discord's own render
    } catch (e) { console.error('[Sniper] observer', e); }
}
let observer = null, observedBody = null;
function attach() {
    try { if (observer) observer.disconnect(); } catch (_) {}
    observedBody = document.body;
    observer = new MutationObserver(onMutations);
    observer.observe(observedBody, { childList: true, subtree: true, characterData: true });
}

// Manual clicks on Roblox links inside Discord: straight into the app, no browser.
window.addEventListener('click', e => {
    if (e.button !== 0) return;
    const a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (!a) return;
    const proto = E.toRobloxProtocol(a.href, location.href);
    if (!proto) return;
    e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
    ipcRenderer.send('w:manual', proto);
}, true);

ipcRenderer.on('cfg', (_e, next) => { applyConfig(next); safeScan(); });
ipcRenderer.on('rescan', () => { done.clear(); texts.clear(); state.ready = false; state.firstSeenAt = 0; state.baseline = 0n; state.channelSince = Date.now(); });

const boot = setInterval(() => {
    if (!document.body || !document.getElementById('app-mount')) return;
    clearInterval(boot);
    attach();
    ipcRenderer.send('w:hello', { loggedIn: loggedIn() });
    checkRoute();
    setInterval(() => {
        if (document.body && document.body !== observedBody) attach();       // self-heal
        checkRoute();
    }, 300);
    setInterval(safeScan, 2000);                                               // safety net
    setInterval(() => ipcRenderer.send('w:status', {
        ready: state.ready, channelId: state.channelId, guildId: state.guildId, baselineCount: state.baselineCount,
        newLinks: state.newLinks, scanned: state.scanned, lastMutationAt: state.lastMutationAt, loggedIn: loggedIn()
    }), 1000);
}, 50);

module.exports = {};
