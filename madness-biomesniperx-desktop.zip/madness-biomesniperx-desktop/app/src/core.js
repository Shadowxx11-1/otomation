"use strict";
// Pure, Electron-free logic: settings, launch gate (lock / duplicates / spam / priority), channel parsing.
const E = require('./engine');

const RULE_WORDS = {
    negators: ['not', 'no', 'nope', 'nah', 'never', 'non', 'isnt', 'wasnt', 'arent', 'aint', 'without', 'dont', 'doesnt', 'didnt', 'cant', 'cannot', 'wont', 'neither'],
    ignoreWords: ['fake', 'fakes', 'false', 'ended', 'ending', 'expired', 'gone', 'dead', 'late', 'despawned', 'notreal', 'over', 'finished', 'inactive', 'unreal', 'vanished', 'disappeared', 'notactive', 'notavailable'],
    realWords: ['real', 'actually', 'legit', 'true']
};

const KNOWN_IDS = new Set(E.BIOMES.map(b => b.id));
const ACCENTS = ['indigo', 'emerald', 'rose', 'amber', 'cyan'];

function defaults() {
    return {
        version: 1,
        enabled: true,
        selection: E.BIOMES.filter(b => b.def).map(b => b.id),
        custom: [],
        watchers: [],
        windowMode: 'hidden',
        rules: {
            joinLockMs: 120000, maxAgeSec: 15, typoMode: 'balanced', contextAI: true, priorityPick: true,
            bypassLockRare: false, spamGuard: true, scanEmbeds: true, settleMs: 400, pairSplit: true, pairWindowSec: 10,
            blockUsers: [], allowUsers: [], extraIgnore: []
        },
        alerts: { sound: true, volume: 70, voice: false, notify: true, webhookEnabled: false, webhookUrl: '' },
        app: { openAtLogin: false, closeToTray: true, startMinimized: false, hotkeys: true, accent: 'indigo' }
    };
}

const num = (v, d, min, max) => { const n = Number(v); return Math.min(max, Math.max(min, Number.isFinite(n) ? n : d)); };
const bool = (v, d) => (typeof v === 'boolean' ? v : d);
const oneOf = (v, list, d) => (list.includes(v) ? v : d);
const ids = v => (Array.isArray(v) ? [...new Set(v.filter(id => KNOWN_IDS.has(id)))] : null);
const words = (v, max = 60) => (Array.isArray(v)
    ? [...new Set(v.map(x => String(x).toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim().replace(/\s+/g, ' ')).filter(x => x.replace(/\s/g, '').length >= 3))].slice(0, max) : []);
const names = v => (Array.isArray(v) ? [...new Set(v.map(x => String(x).trim().toLowerCase()).filter(Boolean))].slice(0, 100) : []);

// "https://discord.com/channels/<guild>/<channel>", "<guild>/<channel>" or "<guild> <channel>"
function parseChannelInput(text) {
    const s = String(text || '').trim();
    let m = /^https:\/\/(?:ptb\.|canary\.)?discord\.com\/channels\/(\d{5,25})\/(\d{5,25})(?:\/\d+)?\/?(?:[?#].*)?$/i.exec(s);
    if (!m) m = /^(\d{5,25})\s*[\/\s,:]\s*(\d{5,25})$/.exec(s);
    return m ? { guildId: m[1], channelId: m[2], url: `https://discord.com/channels/${m[1]}/${m[2]}` } : null;
}

function sanitizeWatcher(w, i) {
    if (!w || typeof w !== 'object') return null;
    const parsed = parseChannelInput(w.url);
    if (!parsed) return null;
    return {
        id: /^w_[a-z0-9]{3,12}$/.test(w.id) ? w.id : 'w_' + Date.now().toString(36) + i,
        label: String(w.label || '').trim().slice(0, 40) || 'Channel ' + parsed.channelId.slice(-4),
        url: parsed.url, guildId: parsed.guildId, channelId: parsed.channelId,
        enabled: bool(w.enabled, true),
        sel: ids(w.sel), custom: Array.isArray(w.custom) ? words(w.custom) : null
    };
}

function sanitize(raw) {
    const d = defaults(), r = raw && typeof raw === 'object' ? raw : {};
    const ru = r.rules || {}, al = r.alerts || {}, ap = r.app || {};
    return {
        version: 1,
        enabled: bool(r.enabled, d.enabled),
        selection: ids(r.selection) || d.selection,
        custom: words(r.custom),
        watchers: (Array.isArray(r.watchers) ? r.watchers : []).slice(0, 3).map(sanitizeWatcher).filter(Boolean),
        windowMode: oneOf(r.windowMode, ['hidden', 'minimized', 'visible'], d.windowMode),
        rules: {
            joinLockMs: num(ru.joinLockMs, d.rules.joinLockMs, 0, 3600000),
            maxAgeSec: num(ru.maxAgeSec, d.rules.maxAgeSec, 0, 600),
            typoMode: oneOf(ru.typoMode, ['strict', 'balanced', 'aggressive'], d.rules.typoMode),
            contextAI: bool(ru.contextAI, d.rules.contextAI),
            priorityPick: bool(ru.priorityPick, d.rules.priorityPick),
            bypassLockRare: bool(ru.bypassLockRare, d.rules.bypassLockRare),
            spamGuard: bool(ru.spamGuard, d.rules.spamGuard),
            scanEmbeds: bool(ru.scanEmbeds, d.rules.scanEmbeds),
            pairSplit: bool(ru.pairSplit, d.rules.pairSplit), pairWindowSec: num(ru.pairWindowSec, d.rules.pairWindowSec, 3, 30),
            settleMs: num(ru.settleMs, d.rules.settleMs, 150, 3000),
            blockUsers: names(ru.blockUsers), allowUsers: names(ru.allowUsers), extraIgnore: names(ru.extraIgnore)
        },
        alerts: {
            sound: bool(al.sound, d.alerts.sound), volume: num(al.volume, d.alerts.volume, 0, 100),
            voice: bool(al.voice, d.alerts.voice), notify: bool(al.notify, d.alerts.notify),
            webhookEnabled: bool(al.webhookEnabled, d.alerts.webhookEnabled), webhookUrl: String(al.webhookUrl || '').slice(0, 300)
        },
        app: {
            openAtLogin: bool(ap.openAtLogin, d.app.openAtLogin), closeToTray: bool(ap.closeToTray, d.app.closeToTray),
            startMinimized: bool(ap.startMinimized, d.app.startMinimized), hotkeys: bool(ap.hotkeys, d.app.hotkeys),
            accent: oneOf(ap.accent, ACCENTS, d.app.accent)
        }
    };
}

// Shallow-per-section merge of a UI patch, then full sanitation.
function applyPatch(current, patch) {
    const next = JSON.parse(JSON.stringify(current));
    for (const key of Object.keys(patch || {})) {
        if (['rules', 'alerts', 'app'].includes(key) && patch[key] && typeof patch[key] === 'object') Object.assign(next[key], patch[key]);
        else if (['enabled', 'selection', 'custom', 'watchers', 'windowMode'].includes(key)) next[key] = patch[key];
    }
    return sanitize(next);
}

const SAFE_WEBHOOK = /^https:\/\/(?:ptb\.|canary\.)?discord\.com\/api\/webhooks\/\d+\/[A-Za-z0-9._-]+$/;
function validWebhook(url) { return SAFE_WEBHOOK.test(String(url || '').trim().replace(/\/$/, '')); }

// What a Discord window needs to know (no secrets, no webhook).
function effectiveConfig(settings, watcher, skewMs, clockOk) {
    const sel = (watcher && watcher.sel) || settings.selection;
    const custom = (watcher && watcher.custom) || settings.custom;
    const r = settings.rules;
    return {
        selection: sel, custom, typoMode: r.typoMode, contextAI: r.contextAI,
        extraIgnore: r.extraIgnore, scanEmbeds: r.scanEmbeds, maxAgeSec: r.maxAgeSec, settleMs: r.settleMs, pairing: r.pairSplit, pairWindowSec: r.pairWindowSec,
        needAuthor: r.blockUsers.length > 0 || r.allowUsers.length > 0, skewMs: skewMs || 0, clockOk: clockOk !== false
    };
}

function makeAnalyzer(cfg) {
    return E.makeAnalyzer({
        negators: RULE_WORDS.negators, ignoreWords: RULE_WORDS.ignoreWords.concat(cfg.extraIgnore || []), realWords: RULE_WORDS.realWords,
        typoMode: cfg.typoMode, contextAI: cfg.contextAI, keywords: E.buildKeywords(cfg.selection, cfg.custom)
    });
}

// ---------------------------------------------------------------------------
// Launch gate: one authority for every watcher window.
// ---------------------------------------------------------------------------
const cmpId = (a, b) => { try { const x = BigInt(a), y = BigInt(b); return x > y ? 1 : x < y ? -1 : 0; } catch (_) { return 0; } };

function createGate(getSettings, now0 = Date.now) {
    const launched = new Map();      // proto -> time
    const recent = [];               // launch timestamps for the spam guard
    let lockUntil = 0, pausedUntil = 0;

    function userBlocked(author, rules) {
        const name = String(author || '').toLowerCase();
        if (!name) return false;     // unknown author: fail open
        if (rules.allowUsers.length && !rules.allowUsers.some(x => name.includes(x))) return true;
        return rules.blockUsers.some(x => name.includes(x));
    }

    function decide(c, now, launchedInBatch, enabled) {
        const rules = getSettings().rules;
        if (!enabled) return 'off';
        if (userBlocked(c.author, rules)) return 'user';
        for (const [key, at] of launched) if (now - at > 15 * 60 * 1000) launched.delete(key);
        if (launched.has(c.proto)) return 'dup';
        if (rules.spamGuard) {
            while (recent.length && now - recent[0] > 20000) recent.shift();
            if (now < pausedUntil) return 'spam';
            if (recent.length >= 4) { pausedUntil = now + 30000; return 'spam'; }
        }
        if (rules.priorityPick && launchedInBatch) return 'skip';
        if (lockUntil > now && !(rules.bypassLockRare && c.pri >= 90)) return 'lock';
        return 'ok';
    }

    function startLock(now) { const ms = getSettings().rules.joinLockMs; if (ms > 0) lockUntil = now + ms; }

    // launchFn runs synchronously the moment a candidate is approved, before any bookkeeping.
    function runBatch(candidates, now, enabled, launchFn) {
        const rules = getSettings().rules;
        const sorted = candidates.slice().sort((a, b) => (rules.priorityPick && b.pri !== a.pri) ? b.pri - a.pri : cmpId(b.msgId, a.msgId));
        const out = [];
        let did = false;
        for (const c of sorted) {
            const verdict = decide(c, now, did, enabled);
            if (verdict === 'ok') {
                const ok = launchFn(c);
                if (ok) { launched.set(c.proto, now); recent.push(now); startLock(now); did = true; }
                out.push({ c, verdict: ok ? 'ok' : 'fail' });
            } else out.push({ c, verdict });
        }
        return out;
    }

    return {
        runBatch, startLock,
        manual(proto, now) { launched.set(proto, now); startLock(now); },
        releaseLock() { lockUntil = 0; pausedUntil = 0; },
        lockLeft(now = now0()) { return Math.max(0, lockUntil - now); },
        pausedLeft(now = now0()) { return Math.max(0, pausedUntil - now); },
        forget(proto) { launched.delete(proto); }
    };
}

module.exports = { RULE_WORDS, defaults, sanitize, applyPatch, parseChannelInput, effectiveConfig, makeAnalyzer, createGate, validWebhook, ACCENTS };
