"use strict";
// Detection engine: Sol's RNG biome/merchant catalogue + typo-tolerant, context-aware analyzer.
// Extracted from Madness BiomeSniperX v12.2 and shared by the main process and the Discord windows.
// =========================================================
// BİYOM KATEGORİLERİ VE ANAHTAR KELİMELER
// kw biçimi: [kelime, en kısa gerçek önek, uyumluluk alanı]
// pri: öncelik (yüksek = önce açılır). Aynı anda iki link gelirse yüksek olan seçilir.
// =========================================================
const GROUPS = [
    { id: 'main', title: '🌦 MAIN BIOMES' },
    { id: 'rare', title: '💎 RARE BIOMES' },
    { id: 'event', title: '🎃 EVENT BIOMES' },
    { id: 'boss', title: '👑 BOSS' },
    { id: 'merchants', title: "🛒 SOL'S RNG MERCHANTS" },
    { id: 'special', title: '🔗 SPECIAL DETECTION' }
];

const BIOMES = [
    { id: 'normal', g: 'main', name: 'Normal', def: false, pri: 1, kw: [['normal', 6, 99]] },
    { id: 'windy', g: 'main', name: 'Windy', def: false, pri: 10, kw: [['windy', 4, 99]] },
    { id: 'snowy', g: 'main', name: 'Snowy', def: false, pri: 10, kw: [['snowy', 4, 99]] },
    { id: 'rainy', g: 'main', name: 'Rainy', def: false, pri: 10, kw: [['rainy', 4, 99]] },
    { id: 'sandstorm', g: 'main', name: 'Sandstorm', def: false, pri: 15, kw: [['sandstorm', 4, 7]] },
    { id: 'hell', g: 'main', name: 'Hell', def: false, pri: 25, kw: [['hell', 4, 99]] },
    { id: 'starfall', g: 'main', name: 'Starfall', def: false, pri: 25, kw: [['starfall', 4, 7]] },
    { id: 'heaven', g: 'main', name: 'Heaven', def: false, pri: 30, kw: [['heaven', 4, 7]] },
    { id: 'lostforest', g: 'main', name: 'Lost Forest', def: false, pri: 20, kw: [['lostforest', 5, 8]] },
    { id: 'corruption', g: 'main', name: 'Corruption', def: false, pri: 30, kw: [['corruption', 4, 8]] },
    { id: 'null', g: 'main', name: 'Null', def: false, pri: 35, kw: [['null', 4, 99]] },

    { id: 'glitched', g: 'rare', name: 'Glitched', def: true, pri: 100, kw: [['glitch', 4, 5]] },
    { id: 'dreamspace', g: 'rare', name: 'Dreamspace', def: true, pri: 100, kw: [['dreamspace', 5, 6]] },
    { id: 'cyberspace', g: 'rare', name: 'Cyberspace', def: true, pri: 95, kw: [['cyberspace', 5, 6]] },
    { id: 'singularity', g: 'rare', name: 'Singularity', def: true, pri: 90, kw: [['singularity', 5, 6]] },
    { id: 'radiant', g: 'rare', name: 'The Radiant Forest', def: true, pri: 80, kw: [['radiantforest', 6, 9], ['radiant', 6, 99]] },

    { id: 'pumpkinmoon', g: 'event', name: 'Pumpkin Moon', def: false, pri: 55, kw: [['pumpkinmoon', 4, 7]] },
    { id: 'graveyard', g: 'event', name: 'Graveyard', def: false, pri: 50, kw: [['graveyard', 5, 8]] },
    { id: 'blazingsun', g: 'event', name: 'Blazing Sun', def: false, pri: 45, kw: [['blazingsun', 4, 7]] },
    { id: 'bloodrain', g: 'event', name: 'Blood Rain', def: false, pri: 50, kw: [['bloodrain', 5, 8]] },
    { id: 'aurora', g: 'event', name: 'Aurora', def: false, pri: 45, kw: [['aurora', 5, 7]] },
    { id: 'eggland', g: 'event', name: 'Eggland', def: false, pri: 40, kw: [['eggland', 4, 7]] },
    { id: 'incinerator', g: 'event', name: 'Incinerator', def: false, pri: 40, kw: [['incinerator', 4, 7]] },

    // 'boss' tam kelime takma adıdır; yalnızca Sinister seçiliyken etkindir.
    { id: 'sinister', g: 'boss', name: 'Sinister', def: true, pri: 70,
        kw: [['sinister', 5, 6], ['boss', 4, 99]] },

    // Exact-name targets from Sol's RNG merchant arrival announcements.
    // Exact-only matching avoids false positives such as "bring" -> "Rin".
    { id: 'merchant_mari', g: 'merchants', name: 'Mari', def: false, pri: 76, merchant: true, kw: [['mari', 4, 99]] },
    { id: 'merchant_rin', g: 'merchants', name: 'Rin', def: false, pri: 78, merchant: true, kw: [['rin', 3, 99]] },
    { id: 'merchant_jester', g: 'merchants', name: 'Jester', def: false, pri: 80, merchant: true, kw: [['jester', 6, 99]] },

    // Special target: accept a recognized Roblox server/share URL only when no authored caption exists.
    // This is a selectable target in the biome list and is included in per-server/channel profiles.
    { id: 'link_only', g: 'special', name: 'Link only (no caption)', def: false, pri: 0, special: true, kw: [] }
];

// Hazır seçim profilleri
const PRESETS = [
    { id: 'default', name: 'Defaults', ids: BIOMES.filter(b => b.def).map(b => b.id) },
    { id: 'rare', name: 'Rare only', ids: BIOMES.filter(b => b.g === 'rare').map(b => b.id) },
    { id: 'halloween', name: 'Halloween', ids: ['pumpkinmoon', 'graveyard', 'bloodrain', 'sinister'] },
    { id: 'events', name: 'All events', ids: BIOMES.filter(b => b.g === 'event' || b.g === 'boss').map(b => b.id) },
    { id: 'all', name: 'Everything', ids: BIOMES.map(b => b.id) },
    { id: 'none', name: 'Clear', ids: [] }
];

function buildKeywords(selectedIds, customWords) {
    const selectedSet = new Set(selectedIds);
    const output = [];

    for (const biome of BIOMES) {
        if (!selectedSet.has(biome.id)) continue;
        for (const [word, minPrefix, typoFrom] of biome.kw) {
            output.push({ id: biome.id, label: biome.name, word, minPrefix, typoFrom, pri: biome.pri, exactOnly: biome.merchant === true, merchant: biome.merchant === true });
        }
    }

    for (const rawWord of customWords || []) {
        const phrase = String(rawWord).toLowerCase()
            .replace(/[^a-z0-9]+/g, ' ').trim().replace(/\s+/g, ' ');
        const word = phrase.replace(/\s/g, '');
        if (word.length >= 3) {
            output.push({ id: 'custom', label: phrase, word, minPrefix: word.length, exactOnly: true, pri: 60 });
        }
    }
    return output;
}

// Sıradan İngilizce kelimeler: bunlar yazım hatası (bulanık) eşleşmesiyle biyom sanılmaz.
// Liste, 275 bin kelimelik sözlük taramasıyla üretildi ve doğrulandı.
const COMMON_WORDS = new Set(["adjuror", "antigravity", "antiradical", "arcadian", "asuror", "asurors", "aurar", "aureola", "auroraly", "aurorean", "bagings", "baizing", "bakings", "baladin", "balading", "balancings", "balating", "balding", "balings", "balking", "balkings", "balming", "barings", "batings", "beading", "beadings", "beaming", "beamings", "beaning", "bearing", "bearings", "beating", "beatings", "bedazing", "begazing", "belacing", "belating", "belaying", "biasing", "biasings", "blabing", "blabings", "blacking", "blackings", "blading", "bladings", "blaging", "blagings", "blahing", "blain", "blaming", "blanding", "blanking", "blankings", "blaring", "blarting", "blasting", "blastings", "blating", "blauding", "blawing", "blazon", "blazoning", "blazonings", "blazons", "bleachings", "blearing", "bleating", "bleatings", "blebing", "blebings", "bleding", "bledings", "bleping", "blesing", "blesings", "bleting", "blining", "bliping", "blising", "bliting", "blitzing", "bloating", "bloatings", "blobing", "blodfin", "blodier", "bloding", "blodings", "blodred", "blodrot", "blods", "blodstain", "blodstains", "blody", "bloging", "blogings", "bloming", "blonder", "bloping", "bloting", "blotings", "blowing", "blowings", "blubing", "blueing", "blueings", "blufing", "bluings", "bluming", "bluring", "boaking", "boating", "boatings", "bozings", "bracing", "bracings", "brading", "braging", "bragings", "braking", "braning", "brasing", "braving", "braying", "brazing", "brezing", "buzings", "bwazi", "caber", "cabers", "cablers", "cambers", "clabers", "clobers", "clubers", "cober", "cobers", "coblers", "coemption", "coemptions", "cofunction", "combers", "combustion", "comutation", "conception", "conduction", "coniption", "coniptions", "consumption", "contraption", "coption", "copulation", "corection", "corections", "corelation", "coreption", "coreptions", "corneti", "cornu", "coronation", "corotation", "corugation", "corugations", "corupted", "corupter", "coruptible", "coruptibly", "coruptionist", "coruptly", "coruscation", "coverup", "crabers", "cribers", "croup", "cuber", "cubers", "cumbers", "curbers", "cybersex", "cyborgs", "cyclers", "cyder", "cyders", "cyphers", "derhams", "dirdams", "dirhams", "drams", "dread", "dreads", "dreamles", "dreamt", "dreamy", "drear", "dreares", "drears", "egplant", "eland", "elfland", "garagey", "garvey", "garveys", "gelande", "glift", "glint", "glits", "glitz", "grace", "grade", "gradely", "grame", "grape", "grapery", "grapey", "grate", "graved", "gravel", "gravels", "gravely", "graven", "graver", "gravers", "gravest", "graveward", "gravida", "gravies", "gravity", "gravs", "gravure", "gravy", "graze", "greave", "greaved", "greaves", "greve", "grove", "haven", "headend", "headmen", "heale", "heame", "heare", "hearken", "hearten", "heathen", "heaved", "heavenly", "heaver", "heavers", "heaves", "heavier", "heavies", "heaving", "heavy", "helve", "incantator", "incarcerator", "incense", "incenser", "incenter", "inching", "inchpin", "incinerating", "incinerations", "incise", "incised", "incises", "incisor", "incite", "incited", "inciter", "inciters", "incites", "incline", "inclined", "incliner", "incliners", "inclines", "incomer", "inconie", "inconue", "inditer", "infiltrator", "ingener", "ingenerate", "ingine", "ingines", "inkines", "inosine", "insaner", "insider", "insigne", "insinew", "insinuator", "intenerate", "intine", "intines", "intoner", "intwine", "invigorator", "inviter", "nonbearing", "nonconduction", "nonconsumption", "noncorelation", "nonormal", "norma", "normalcy", "norman", "normans", "normas", "nosebands", "nosines", "nosings", "plump", "pumping", "pumpion", "pumpking", "pumpkings", "pumpkinsed", "pumps", "radial", "radiale", "radials", "radialy", "radiance", "radiancy", "radians", "radiantly", "radiata", "radiate", "radiator", "radical", "radicand", "radicant", "radioman", "rainforest", "rampant", "reliant", "resiant", "roadman", "saidest", "saids", "saidst", "sandabs", "sandals", "sandeks", "sanders", "sandhis", "sandiest", "sandles", "sandlot", "sandpit", "sandshoe", "sandspur", "sandstone", "sandstones", "sandworm", "sandy", "saned", "sanes", "sanest", "sangs", "sants", "sards", "sawdust", "scand", "scarf", "sebands", "secularity", "sends", "sensist", "sexangular", "shand", "shands", "shinies", "shiniest", "sienite", "siliest", "similarity", "simis", "simonist", "simular", "sinds", "sines", "sinful", "sinfuly", "singe", "sings", "singularise", "singularised", "singularises", "singularism", "singularisms", "singularist", "singularists", "singularities", "singularize", "singularized", "singularizes", "singularly", "singularnes", "singulars", "singulary", "singult", "singults", "sinhs", "sinisterity", "sinisterly", "sinisternes", "sinkiest", "sinks", "sinopis", "sinuate", "sinus", "siris", "sisiest", "sitar", "sizeist", "siziest", "sizist", "sizists", "skinful", "skinies", "skiniest", "slaister", "slangular", "snarf", "snifter", "solands", "songful", "songster", "spatfal", "specularity", "spinies", "spiniest", "spinmeister", "spinster", "spinula", "stadial", "stair", "stand", "standes", "stands", "stare", "stark", "starn", "stars", "start", "startful", "stary", "stear", "sternal", "stingbul", "straf", "strands", "stratal", "subangular", "subminister", "sumands", "suniest", "sunis", "swarf", "swinish", "synds"]);

// =========================================================
// METİN ANALİZİ
// - Kısaltma/önek (singu -> Singularity), ek (glitched, glitchy)
// - Yazım hatası: strict / balanced / aggressive
// - Olumsuz, sahte, bitmiş mesajları engelleme ("not cyber", "glitch ended")
// - Acele ifadeleri olumlu sayma ("dont miss glitch")
// =========================================================
function makeAnalyzer(CFG) {
    const LEET = { '0': 'o', '1': 'i', '3': 'e', '4': 'a', '5': 's', '7': 't', '@': 'a', '$': 's' };
    const collapse = value => value.replace(/(.)\1+/g, '$1');
    const MODE = ['strict', 'balanced', 'aggressive'].includes(CFG.typoMode) ? CFG.typoMode : 'balanced';
    const CONTEXT_AI = CFG.contextAI !== false;

    // Çift harfi anlamlı olan kısa kelimeler (hell/heel, boss) bozulmasın diye korunur.
    const PRESERVE = ['boss', 'hell'];
    const preserveRes = PRESERVE.map(word => {
        const runs = word.match(/(.)\1*/g) || [];
        const body = runs.map(run => run.length > 1 ? run[0] + '{2,}' : run[0] + '+').join('');
        return [new RegExp('^' + body + '$'), word];
    });
    const normalizeToken = value => {
        for (const [re, word] of preserveRes) if (re.test(value)) return word;
        return collapse(value);
    };

    // Damerau-Levenshtein (bitişik harf yer değiştirmesi dahil), erken çıkışlı.
    function distance(a, b, max) {
        const n = a.length, m = b.length;
        if (Math.abs(n - m) > max) return max + 1;
        if (!n) return m;
        if (!m) return n;
        const inf = n + m;
        const d = Array.from({ length: n + 2 }, () => new Array(m + 2).fill(0));
        d[0][0] = inf;
        for (let i = 0; i <= n; i++) { d[i + 1][0] = inf; d[i + 1][1] = i; }
        for (let j = 0; j <= m; j++) { d[0][j + 1] = inf; d[1][j + 1] = j; }
        const lastSeen = Object.create(null);
        for (let i = 1; i <= n; i++) {
            let lastMatchColumn = 0;
            for (let j = 1; j <= m; j++) {
                const previousRow = lastSeen[b[j - 1]] || 0;
                const previousColumn = lastMatchColumn;
                let cost = 1;
                if (a[i - 1] === b[j - 1]) { cost = 0; lastMatchColumn = j; }
                d[i + 1][j + 1] = Math.min(
                    d[i][j] + cost,
                    d[i + 1][j] + 1,
                    d[i][j + 1] + 1,
                    d[previousRow][previousColumn] + (i - previousRow - 1) + 1 + (j - previousColumn - 1)
                );
            }
            lastSeen[a[i - 1]] = i;
        }
        return d[n + 1][m + 1];
    }

    const maxTypos = len => (len < 6 ? 0 : len <= 7 ? 1 : len <= 12 ? 2 : 3);
    // Yanlış harfle başlayan kelimeler (minister -> sinister) eşleşmez; ilk iki harf yer değiştirebilir.
    const opens = (token, full) => token[0] === full[0] || (token[0] === full[1] && token[1] === full[0]);
    const SUFFIXES = new Set(['s', 'es', 'ed', 'y', 'ing']);

    const KW = (CFG.keywords || []).map(keyword => {
        const rawWord = String(keyword.word).toLowerCase();
        const full = PRESERVE.includes(rawWord) ? rawWord : collapse(rawWord);
        const requestedPrefix = Number(keyword.minPrefix) || 3;
        return {
            label: keyword.label,
            full,
            pri: Number(keyword.pri) || 0,
            minPrefix: Math.max(3, Math.min(requestedPrefix, full.length)),
            exactOnly: keyword.exactOnly === true,
            merchant: keyword.merchant === true
        };
    });

    const NEG = (CFG.negators || []).map(word => collapse(String(word).toLowerCase()));
    const IGN = (CFG.ignoreWords || []).map(word => collapse(String(word).toLowerCase()));
    const REAL = (CFG.realWords || []).map(word => collapse(String(word).toLowerCase()));
    const NEG_SET = new Set(NEG), IGN_SET = new Set(IGN), REAL_SET = new Set(REAL);
    const BLOCK_LIST = NEG.concat(IGN);
    const BLOCK_SET = new Set(BLOCK_LIST);

    function inList(token, set, list) {
        if (!token) return false;
        if (set.has(token)) return true;
        if (token.length >= 6) {
            for (const word of list) {
                if (word.length >= 6 && Math.abs(word.length - token.length) <= 1 && distance(token, word, 1) <= 1) return true;
            }
        }
        return false;
    }
    const isNeg = token => inList(token, NEG_SET, NEG);
    const isIgn = token => inList(token, IGN_SET, IGN);
    const isBlock = token => inList(token, BLOCK_SET, BLOCK_LIST);

    const memo = new Map();
    function matchKeyword(token, fullOnly = false) {
        const key = (fullOnly ? '1' : '0') + token;
        if (memo.has(key)) return memo.get(key);
        const result = matchUncached(token, fullOnly);
        if (memo.size > 4000) memo.clear();
        memo.set(key, result);
        return result;
    }

    function matchUncached(token, fullOnly) {
        const fuzzyOk = MODE !== 'strict' && !COMMON_WORDS.has(token);
        for (const keyword of KW) {
            const full = keyword.full;
            if (token === full) return keyword;
            if (keyword.exactOnly) continue;

            if (!fullOnly) {
                // Kısaltma: singu -> singularity, glit -> glitch
                if (token.length >= keyword.minPrefix && token.length < full.length && full.startsWith(token)) return keyword;
                // Ek: glitched, glitchy, glitches, cyberspaces
                if (full.length >= 5 && token.length > full.length && token.startsWith(full) &&
                    SUFFIXES.has(token.slice(full.length))) return keyword;
            }

            if (!fuzzyOk) continue;

            // Tam kelimeye yakın yazım hatası: glicth, cybrspace, dreamspce
            const allowed = maxTypos(full.length);
            if (allowed && token.length >= keyword.minPrefix && Math.abs(token.length - full.length) <= 1 &&
                opens(token, full) && distance(token, full, allowed) <= allowed) return keyword;

            if (fullOnly) continue;

            // Dengeli mod: bozuk yazılmış kısaltma (cybrsp -> cybersp)
            if (token.length >= 6 && full.length >= 7 && opens(token, full)) {
                const top = Math.min(full.length - 1, token.length + 1);
                for (let len = Math.max(keyword.minPrefix, token.length - 1); len <= top; len++) {
                    if (distance(token, full.slice(0, len), 1) <= 1) return keyword;
                }
            }

            // Agresif mod: çok bozuk yazımlar (cyybeber -> cyber)
            if (MODE === 'aggressive' && token.length >= 5 && full.length >= 6 && opens(token, full)) {
                const allow = token.length <= 6 ? 1 : token.length <= 9 ? 2 : 3;
                for (let len = keyword.minPrefix; len <= full.length; len++) {
                    if (Math.abs(token.length - len) <= allow && distance(token, full.slice(0, len), allow) <= allow) return keyword;
                }
            }
        }
        return null;
    }

    function tokenize(raw) {
        const normalized = String(raw || '')
            .replace(/https?:\/\/\S+/gi, ' ')
            .replace(/İ/g, 'i').replace(/ı/g, 'i')
            .toLowerCase()
            .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
            .replace(/['’`´]/g, '');
        return normalized
            .split(/[^a-z0-9@$]+/)
            .filter(Boolean)
            .map(token => {
                if (!/[a-z]/.test(token)) return '';
                return normalizeToken(token.replace(/[013457@$]/g, char => LEET[char]).replace(/[^a-z]/g, ''));
            })
            .filter(Boolean);
    }

    // Token'lar harf tekrarsız tutulduğu için kümeler de aynı biçimde hazırlanır (miss -> mis).
    const toSet = list => new Set(list.map(word => collapse(word)));
    const CONNECTORS = toSet(['but', 'however', 'although', 'yet', 'and', 'while', 'also', 'then']);
    const FILLERS = toSet([
        'is', 'are', 'was', 'were', 'has', 'have', 'had', 'seems', 'looks', 'already', 'just', 'now',
        'totally', 'completely', 'basically', 'currently', 'really', 'actually', 'been', 'got', 'its',
        'too', 'to', 'so', 'very', 'way', 'alr', 'prob', 'probably', 'maybe', 'kinda', 'pretty',
        'almost', 'long', 'be', 'it', 'this', 'that', 'here', 'there'
    ]);
    // "dont miss", "cant miss", "wont last" = acele et (olumlu)
    const URGE = toSet(['miss', 'missing', 'sleep', 'skip', 'wait', 'forget', 'lose', 'ignore', 'hesitate', 'delay', 'waste', 'last', 'stop']);
    const OVER_OK = toSet(['here', 'there', 'at', 'in', 'on', 'by', 'the', 'this']);

    // Local contextual classifier (not a remote LLM): detects wishes, hypotheticals,
    // uncertainty and availability questions around the matched biome. Turkish + English.
    const WISH_BEFORE = toSet([
        'wish', 'wishes', 'wishing', 'hope', 'hoping', 'hopefully', 'imagine', 'imagining',
        'ifonly', 'want', 'wanna', 'waiting', 'dream', 'dreaming', 'keske', 'umarim', 'insallah'
    ]);
    const HYPOTHETICAL = toSet([
        'maybe', 'might', 'perhaps', 'probably', 'someday', 'sometime', 'would', 'could', 'if', 'when', 'think',
        'olsa', 'olsaydi', 'ciksa', 'ciksin', 'gelse', 'gelirse', 'gelecek', 'olacak'
    ]);
    const CURRENT_CUES = toSet([
        'now', 'currently', 'active', 'spawned', 'spawning',
        'appeared', 'arrived', 'live', 'confirmed', 'found', 'available', 'geldi',
        'cikti', 'burada', 'mevcut', 'aktif', 'oldu'
    ]);
    const QUESTION_CUES = toSet(['any', 'anyone', 'somebody', 'someone', 'there', 'mi', 'mu', 'mı', 'mü']);

    function contextReason(tokens, start, end) {
        if (!CONTEXT_AI) return null;
        const left = tokens.slice(Math.max(0, start - 5), start);
        const right = tokens.slice(end + 1, Math.min(tokens.length, end + 6));
        const local = left.concat(tokens.slice(start, end + 1), right);
        const hasStrongCurrent = local.some(word => CURRENT_CUES.has(word));
        const hasWishBefore = left.some(word => WISH_BEFORE.has(word));
        const hasWishAfter = right.some(word => WISH_BEFORE.has(word));
        const hasHypothetical = local.some(word => HYPOTHETICAL.has(word));
        const hasLocation = local.some(word => word === 'here' || word === 'there');

        // Availability questions are not proof that the biome is live.
        const asksAvailability = (right.includes('mi') || right.includes('mu')) && right.some(word => ['var', 'there', 'spawn', 'available'].includes(word));
        const asksInEnglish = left.some(word => ['any', 'anyone', 'someone', 'somebody'].includes(word)) ||
            (left.includes('is') && right.includes('there'));
        if ((asksAvailability || asksInEnglish) && !hasStrongCurrent) return 'context: availability question';

        // Turkish wish/subjunctive forms are strong signals: "keşke glitch çıksa".
        const turkishWish = left.some(word => ['keske', 'umarim', 'insallah'].includes(word)) ||
            right.some(word => ['olsa', 'olsaydi', 'ciksa', 'ciksin', 'gelse', 'gelirse'].includes(word));
        if (turkishWish && !hasStrongCurrent) return 'context: wish / hypothetical (TR)';
        if ((hasWishBefore || hasWishAfter) && !hasStrongCurrent) return 'context: wish / speculation';

        // "glitch might be here" and "glitch could spawn" remain speculative.
        if (hasHypothetical && !hasStrongCurrent && (hasLocation || left.includes('if') || local.some(word => ['maybe', 'might', 'perhaps', 'probably', 'would', 'could', 'think'].includes(word)) || right.includes('soon') || right.includes('someday') || right.includes('spawn'))) {
            return 'context: hypothetical / not confirmed';
        }
        return null;
    }

    function negationReason(tokens, start, end) {
        // Keyword'den ÖNCE gelen olumsuzluk
        for (let i = start - 1; i >= Math.max(0, start - 3); i--) {
            const word = tokens[i];
            if (CONNECTORS.has(word)) break;
            if (isIgn(word) && tokens[i - 1] && isNeg(tokens[i - 1])) { i--; continue; }   // "not fake glitch"
            if (isNeg(word) && URGE.has(tokens[i + 1])) continue;                           // "dont miss glitch"
            if (isBlock(word)) return 'preceded by "' + word + '"';
        }

        // Keyword'den SONRA gelen durum ifadeleri
        for (let i = end + 1; i <= Math.min(tokens.length - 1, end + 4); i++) {
            const word = tokens[i];
            if (CONNECTORS.has(word)) break;

            if (isIgn(word)) {
                if (word === 'over' && OVER_OK.has(tokens[i + 1])) continue;                // "glitch over here"
                const previous = tokens[i - 1], previousTwo = tokens[i - 2];
                if (isNeg(previous) || (previous === 'longer' && previousTwo === 'no')) return null;
                return 'followed by "' + word + '"';
            }

            if (word === 'no' && tokens[i + 1] === 'longer') return 'followed by "no longer"';

            if (isNeg(word)) {
                if (REAL_SET.has(tokens[i + 1])) return 'followed by "' + word + ' ' + tokens[i + 1] + '"';
                if (isIgn(tokens[i + 1]) || URGE.has(tokens[i + 1])) return null;           // "not gone", "dont miss"
                break;
            }

            if (!FILLERS.has(word)) break;
        }
        return null;
    }

    // Block explicit merchant absence statements: "Rin has not arrived" / "Jester isn't here".
    function merchantAbsenceReason(tokens, start, end) {
        const tail = tokens.slice(end + 1, Math.min(tokens.length, end + 7));
        const absenceCues = toSet(['arrived', 'spawned', 'spawn', 'here', 'available', 'present', 'around', 'active', 'appeared']);
        for (let i = 0; i < tail.length; i++) {
            if (!isNeg(tail[i])) continue;
            if (tail.slice(i + 1, i + 4).some(word => absenceCues.has(word))) {
                return 'merchant status negated: "' + tail.slice(i, i + 4).join(' ') + '"';
            }
        }
        return null;
    }

    function analyze(raw) {
        const tokens = tokenize(raw);
        const hits = [];
        if (!KW.length) return { tokens, hits, snipe: false, word: null, pri: 0, merchant: false };

        for (let i = 0; i < tokens.length; i++) {
            const token = tokens[i];
            const attachedNegative = /^(not|non|no|fake|anti)(.{3,})$/.exec(token);
            if (attachedNegative) {
                const negativeMatch = matchKeyword(attachedNegative[2]);
                if (negativeMatch) {
                    hits.push({ word: negativeMatch.label, pri: negativeMatch.pri, merchant: negativeMatch.merchant, negated: true, why: 'attached negation: ' + token });
                    continue;
                }
            }

            let match = matchKeyword(token);
            let end = i;
            if (!match && !isBlock(token)) {
                for (let count = 2; count <= 3 && i + count - 1 < tokens.length && !match; count++) {
                    const parts = tokens.slice(i, i + count);
                    if (parts.slice(1).some(part => matchKeyword(part))) break;
                    const joinedMatch = matchKeyword(parts.join(''), true);
                    if (joinedMatch) { match = joinedMatch; end = i + count - 1; }
                }
            }
            if (!match) continue;

            const merchantAbsence = match.merchant ? merchantAbsenceReason(tokens, i, end) : null;
            const why = negationReason(tokens, i, end) || merchantAbsence || contextReason(tokens, i, end);
            hits.push({ word: match.label, pri: match.pri, merchant: match.merchant, negated: Boolean(why), why: why || '' });
            i = end;
        }

        let best = null;
        for (const hit of hits) if (!hit.negated && (!best || hit.pri > best.pri)) best = hit;
        return { tokens, hits, snipe: Boolean(best), word: best ? best.word : null, pri: best ? best.pri : 0,
            merchant: best ? best.merchant === true : false };
    }

    return { analyze, tokenize };
}

// ---- Roblox web link -> roblox:// (pure) ----
function toRobloxProtocol(href, base) {
    if (/^roblox:\/\//i.test(String(href))) return SAFE_PROTO.test(String(href)) ? String(href) : null;
    let url;
    try { url = new URL(href, base || 'https://discord.com/'); } catch (e) { return null; }
    if (!/^(www\.|web\.)?roblox\.com$/i.test(url.hostname)) return null;
    const path = url.pathname.replace(/\/+$/, '');
    const q = url.searchParams;
    const enc = encodeURIComponent;
    if (path === '/share' || path === '/share-links') {
        const code = q.get('code'), type = q.get('type');
        if (code && type && /^[A-Za-z0-9_-]{6,64}$/.test(code) && /^[A-Za-z]{3,20}$/.test(type)) {
            return `roblox://navigation/share_links?code=${enc(code)}&type=${enc(type)}`;
        }
    }
    if (/^\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?games\/start$/i.test(path)) {
        const pid = q.get('placeId'), pc = q.get('privateServerLinkCode') || q.get('linkCode'), gi = q.get('gameInstanceId');
        if (pid && /^\d+$/.test(pid)) {
            if (pc && /^\d{10,40}$/.test(pc)) return `roblox://placeID=${pid}&linkCode=${enc(pc)}`;
            if (gi && /^[0-9a-fA-F-]{16,64}$/.test(gi)) return `roblox://experiences/start?placeId=${pid}&gameInstanceId=${enc(gi)}`;
        }
    }
    const m = path.match(/^\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?games\/(\d+)/i);
    if (m) {
        const privateCode = q.get('privateServerLinkCode');
        if (privateCode && /^\d{10,40}$/.test(privateCode)) return `roblox://placeID=${m[1]}&linkCode=${enc(privateCode)}`;
        const instanceId = q.get('gameInstanceId');
        if (instanceId && /^[0-9a-fA-F-]{16,64}$/.test(instanceId)) return `roblox://experiences/start?placeId=${m[1]}&gameInstanceId=${enc(instanceId)}`;
    }
    return null;
}

// Defence in depth: the main process only ever launches links that pass this check.
const SAFE_PROTO = /^roblox:\/\/(?:navigation\/share_links\?code=[A-Za-z0-9_-]{6,64}&type=[A-Za-z]{3,20}|placeID=\d+&linkCode=\d{10,40}|experiences\/start\?placeId=\d+&gameInstanceId=[0-9a-fA-F-]{16,64})$/;

module.exports = { GROUPS, BIOMES, PRESETS, buildKeywords, makeAnalyzer, toRobloxProtocol, SAFE_PROTO };
