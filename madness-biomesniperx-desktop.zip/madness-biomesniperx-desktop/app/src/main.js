"use strict";
const { app, BrowserWindow, Tray, Menu, ipcMain, shell, session, globalShortcut, Notification, net, nativeImage } = require('electron');
const path = require('path');
const fs = require('fs');
const core = require('./core');
const E = require('./engine');
const pkg = require('../package.json');

// ---- speed & stability: keep every renderer at full speed even when hidden/minimised ----
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.commandLine.appendSwitch('disable-background-timer-throttling');
app.commandLine.appendSwitch('disable-backgrounding-occluded-windows');
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
const CHROME_UA = app.userAgentFallback.replace(/\sElectron\/\S+/, '').replace(/\sMadness[^/\s]*\/\S+/i, '').replace(new RegExp('\\s' + pkg.name + '\\/\\S+'), '');
app.userAgentFallback = CHROME_UA;

if (!app.requestSingleInstanceLock()) { app.quit(); process.exit(0); }

const PART = 'persist:discord';                       // Discord login lives here; the app never reads it
const ICON = path.join(__dirname, '..', 'assets', 'icon.png');
const DISCORD_HOST = /^https:\/\/(?:[\w-]+\.)?discord(?:app)?\.com\//i;

// ---------------------------------------------------------------------------
// persistence
// ---------------------------------------------------------------------------
const file = name => path.join(app.getPath('userData'), name);
function readJson(name, fallback) { try { return JSON.parse(fs.readFileSync(file(name), 'utf8')); } catch (_) { return fallback; } }
function writeJson(name, data) {
    try { const tmp = file(name) + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(data)); fs.renameSync(tmp, file(name)); } catch (e) { console.error('save failed', e); }
}
let saveTimer = null;
const saveSoon = () => { clearTimeout(saveTimer); saveTimer = setTimeout(() => { writeJson('settings.json', settings); writeJson('history.json', history); }, 250); };

let settings = core.defaults(), history = [];
const gate = core.createGate(() => settings);

// ---------------------------------------------------------------------------
// runtime state
// ---------------------------------------------------------------------------
const rt = {
    startedAt: Date.now(), skewMs: 0, clockOk: false, clockState: 'syncing', feedSeq: 0, feed: [], last: null,
    webhookStatus: '', lastWebhookAt: 0, quitting: false, protoById: new Map(), lastProto: null, lastTarget: ''
};
const watchers = new Map();        // watcher id -> { win, status, ctx, prompted }
const wcToWatcher = new Map();     // webContents.id -> watcher id ('signin' for the sign-in window)
let control = null, tray = null, signin = null;

function pushFeed(kind, text, extra = {}) {
    const item = { id: ++rt.feedSeq, t: Date.now(), kind, text: String(text).slice(0, 160), ...extra };
    rt.feed.unshift(item); if (rt.feed.length > 40) rt.feed.pop();
    if (extra.proto) { rt.protoById.set(item.id, extra.proto); if (rt.protoById.size > 120) rt.protoById.delete(rt.protoById.keys().next().value); delete item.proto; item.canOpen = true; }
    return item;
}

// ---------------------------------------------------------------------------
// launching: straight into the Roblox client, no browser, no prompt
// ---------------------------------------------------------------------------
function launchRoblox(proto) {
    if (!E.SAFE_PROTO.test(proto)) return false;
    shell.openExternal(proto).catch(err => {
        gate.forget(proto); gate.releaseLock();
        pushFeed('fail', 'Roblox could not be launched: ' + (err && err.message ? err.message : 'unknown error'));
        scheduleState();
    });
    return true;
}

function manualLaunch(proto, source = 'manual') {
    if (!E.SAFE_PROTO.test(proto)) return false;
    const ok = launchRoblox(proto);
    if (ok) { gate.manual(proto, Date.now()); rt.lastProto = proto; pushFeed('manual', source === 'manual' ? 'Opened manually' : source, { proto }); scheduleState(); }
    return ok;
}

function handleBatch(wid, b) {
    const recvAt = Date.now();
    const raw = Array.isArray(b && b.items) ? b.items.slice(0, 40) : [];
    const items = raw.filter(c => c && typeof c.proto === 'string' && E.SAFE_PROTO.test(c.proto)).map(c => ({
        proto: c.proto, pri: Number(c.pri) || 0, msgId: String(c.msgId || '0').slice(0, 24), word: String(c.word || 'Unknown').slice(0, 40),
        merchant: c.merchant === true, linkOnly: c.linkOnly === true, preview: String(c.preview || '').slice(0, 80),
        author: c.author == null ? null : String(c.author).slice(0, 60), ageSec: Number(c.ageSec) || 0
    }));
    if (!items.length) return;
    const procMs = Number(b.procMs) || 0, ipcMs = Math.max(0, recvAt - (Number(b.sentAt) || recvAt));
    const w = watchers.get(wid);
    const label = w && w.label || 'Discord';

    const results = gate.runBatch(items, recvAt, settings.enabled, c => launchRoblox(c.proto));
    const launchMs = Date.now() - recvAt;

    for (const { c, verdict } of results) {
        const tag = c.word + ' · ' + (c.preview || '(link only)');
        if (verdict === 'ok') {
            const entry = {
                t: recvAt, target: c.word, merchant: c.merchant, user: c.author || '', ageSec: c.ageSec, procMs: Math.round(procMs * 10) / 10,
                ipcMs, launchMs, totalMs: Math.round((procMs + ipcMs + launchMs) * 10) / 10, watcher: label
            };
            rt.last = entry; rt.lastProto = c.proto; rt.lastTarget = c.word;
            history.unshift(entry); if (history.length > 300) history.length = 300;
            pushFeed('launch', tag + ' · ' + c.ageSec + 's old', { proto: c.proto, watcher: label });
            afterLaunch(entry, c);
        } else if (verdict === 'lock' || verdict === 'spam') {
            pushFeed('held', tag + (verdict === 'lock' ? ' · held by join lock' : ' · held by spam guard'), { proto: c.proto, watcher: label });
            send(control, 'held', { target: c.word });
        } else if (verdict === 'fail') pushFeed('fail', tag + ' · launch failed');
        else if (verdict === 'dup') pushFeed('dup', tag + ' · duplicate');
        else if (verdict === 'user') pushFeed('user', tag + ' · filtered user');
        else if (verdict === 'skip') pushFeed('skip', tag + ' · lower priority');
        else if (verdict === 'off') pushFeed('off', tag + ' · sniper paused');
    }
    saveSoon(); scheduleState();
}

// Everything non-essential happens AFTER the launch call.
function afterLaunch(entry, c) {
    send(control, 'launch', { target: entry.target, merchant: entry.merchant, pri: c.pri });
    if (settings.alerts.notify && Notification.isSupported()) {
        try { new Notification({ title: (entry.merchant ? '🛒 ' : '🚀 ') + entry.target, body: 'Launching Roblox · reaction ' + entry.totalMs + ' ms', silent: true }).show(); } catch (_) {}
    }
    if (tray) tray.setToolTip('Madness BiomeSniperX · last: ' + entry.target);
    sendWebhook(entry);
}

// ---------------------------------------------------------------------------
// webhook (optional, user-owned; never includes links or user names)
// ---------------------------------------------------------------------------
async function sendWebhook(entry, isTest = false) {
    if (!isTest && !settings.alerts.webhookEnabled) return;
    const url = String(settings.alerts.webhookUrl || '').trim().replace(/\/$/, '');
    if (!core.validWebhook(url)) { rt.webhookStatus = 'Invalid or missing Discord webhook URL'; return scheduleState(); }
    const now = Date.now();
    if (!isTest && now - rt.lastWebhookAt < 1000) return;
    rt.lastWebhookAt = now;
    const embed = isTest
        ? { title: '🧪 Webhook test', description: 'Madness BiomeSniperX Desktop can reach this channel.', color: 0x5865F2 }
        : {
            title: entry.merchant ? "🛒 Sol's RNG merchant detected" : "🌌 Sol's RNG biome detected",
            description: '**' + entry.target + '** matched your filters. A Roblox launch request was sent.',
            color: entry.merchant ? 0xE6A23C : 0x5865F2,
            fields: [
                { name: entry.merchant ? 'Merchant' : 'Biome', value: '**' + entry.target + '**', inline: true },
                { name: 'Message age', value: entry.ageSec + ' s', inline: true },
                { name: 'Reaction', value: entry.totalMs + ' ms', inline: true }
            ],
            timestamp: new Date(entry.t).toISOString()
        };
    embed.footer = { text: 'Madness BiomeSniperX Desktop v' + pkg.version };
    rt.webhookStatus = 'Sending…'; scheduleState();
    try {
        const res = await net.fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ embeds: [embed] }) });
        rt.webhookStatus = res.ok ? (isTest ? 'Test message delivered ✓' : 'Last report delivered ✓') : 'Webhook error: HTTP ' + res.status;
    } catch (_) { rt.webhookStatus = 'Webhook network error'; }
    scheduleState();
}

// ---------------------------------------------------------------------------
// clock offset (PC vs Discord server) so "live-only" age checks are exact
// ---------------------------------------------------------------------------
async function syncClock() {
    try {
        const t0 = Date.now();
        const res = await net.fetch('https://discord.com/robots.txt', { cache: 'no-store' });
        const t1 = Date.now();
        const server = Date.parse(res.headers.get('date')) + Number(res.headers.get('age') || 0) * 1000;
        if (!Number.isFinite(server)) throw new Error('no date');
        rt.skewMs = (server + 500) - (t0 + t1) / 2; rt.clockOk = true; rt.clockState = 'synced';
    } catch (_) { rt.skewMs = 0; rt.clockOk = false; rt.clockState = 'unsynced'; setTimeout(syncClock, 15000); }
    broadcastCfg(); scheduleState();
}

// ---------------------------------------------------------------------------
// Discord windows
// ---------------------------------------------------------------------------
function discordWindow(title, wid) {
    const win = new BrowserWindow({
        width: 1100, height: 720, show: false, title, backgroundColor: '#313338', autoHideMenuBar: true, icon: ICON,
        webPreferences: {
            partition: PART, preload: path.join(__dirname, 'discord-preload.js'), contextIsolation: true, nodeIntegration: false,
            sandbox: false, backgroundThrottling: false, spellcheck: false, webSecurity: true
        }
    });
    wcToWatcher.set(win.webContents.id, wid);
    win.webContents.setBackgroundThrottling(false);
    win.webContents.setWindowOpenHandler(({ url }) => {
        const proto = E.toRobloxProtocol(url);
        if (proto) manualLaunch(proto);
        else if (/^https?:\/\//i.test(url)) shell.openExternal(url).catch(() => {});
        return { action: 'deny' };
    });
    win.webContents.on('will-navigate', (ev, url) => {
        if (!DISCORD_HOST.test(url)) { ev.preventDefault(); const proto = E.toRobloxProtocol(url); if (proto) manualLaunch(proto); else if (/^https?:\/\//i.test(url)) shell.openExternal(url).catch(() => {}); }
    });
    win.on('close', ev => { if (!rt.quitting) { ev.preventDefault(); win.hide(); } });
    win.on('closed', () => wcToWatcher.delete(win.webContents.id));
    return win;
}

function applyWindowMode(win) {
    if (!win || win.isDestroyed()) return;
    if (settings.windowMode === 'visible') win.show();
    else if (settings.windowMode === 'minimized') { win.showInactive(); win.minimize(); }
    else win.hide();
}

function ensureWatcherWindows() {
    const wanted = new Map(settings.watchers.filter(w => w.enabled).map(w => [w.id, w]));
    for (const [id, rec] of watchers) {
        const w = wanted.get(id);
        if (!w) { rt.quitting = true; try { rec.win.destroy(); } catch (_) {} rt.quitting = false; watchers.delete(id); }
        else if (rec.url !== w.url) { rec.url = w.url; rec.win.loadURL(w.url); }
        rec.label = w ? w.label : rec.label;
    }
    for (const w of wanted.values()) {
        if (watchers.has(w.id)) continue;
        const win = discordWindow('Discord · ' + w.label, w.id);
        watchers.set(w.id, { win, label: w.label, url: w.url, status: null, ctx: null, prompted: false });
        win.loadURL(w.url);
        win.once('ready-to-show', () => applyWindowMode(win));
    }
}

function openSignIn() {
    if (signin && !signin.isDestroyed()) { signin.show(); signin.focus(); return; }
    signin = discordWindow('Sign in to Discord', 'signin');
    signin.loadURL('https://discord.com/login');
    signin.once('ready-to-show', () => signin.show());
}

function openWatcherWindow(id) {
    if (id === 'signin') return openSignIn();
    const rec = watchers.get(id);
    if (rec && !rec.win.isDestroyed()) { rec.win.show(); rec.win.restore(); rec.win.focus(); }
}

function broadcastCfg() {
    for (const [id, rec] of watchers) {
        const w = settings.watchers.find(x => x.id === id);
        if (!rec.win.isDestroyed()) rec.win.webContents.send('cfg', core.effectiveConfig(settings, w, rt.skewMs, rt.clockOk));
    }
}

// ---------------------------------------------------------------------------
// IPC from Discord windows (validated: only our own windows are accepted)
// ---------------------------------------------------------------------------
const widOf = e => wcToWatcher.get(e.sender.id) || null;
ipcMain.on('w:hello', e => {
    const wid = widOf(e); if (!wid) return;
    const w = settings.watchers.find(x => x.id === wid);
    e.sender.send('cfg', core.effectiveConfig(settings, w, rt.skewMs, rt.clockOk));
});
ipcMain.on('w:ctx', (e, ctx) => { const wid = widOf(e); const rec = watchers.get(wid); if (rec && ctx) { rec.ctx = ctx; scheduleState(); } });
ipcMain.on('w:status', (e, st) => {
    const wid = widOf(e); const rec = watchers.get(wid);
    if (!rec || !st) return;
    rec.status = { ready: !!st.ready, loggedIn: !!st.loggedIn, channelId: st.channelId || null, baselineCount: Number(st.baselineCount) || 0,
        newLinks: Number(st.newLinks) || 0, scanned: Number(st.scanned) || 0, lastMutationAt: Number(st.lastMutationAt) || 0, at: Date.now() };
    if (!rec.status.loggedIn && !rec.prompted) { rec.prompted = true; rec.win.show(); rec.win.focus(); }     // first run: let the user sign in
    if (rec.status.loggedIn && rec.prompted && !rec.hidAfterLogin) { rec.hidAfterLogin = true; applyWindowMode(rec.win); }
    scheduleState();
});
ipcMain.on('w:evt', (e, ev) => { if (widOf(e) && ev && (ev.kind === 'block' || ev.kind === 'nolink')) { pushFeed(ev.kind, String(ev.text || '')); scheduleState(); } });
ipcMain.on('w:batch', (e, b) => { const wid = widOf(e); if (wid && wid !== 'signin') handleBatch(wid, b); });
ipcMain.on('w:manual', (e, proto) => { if (widOf(e) && typeof proto === 'string') manualLaunch(proto); });

// ---------------------------------------------------------------------------
// IPC from the control centre
// ---------------------------------------------------------------------------
function snapshot() {
    const now = Date.now();
    const startOfDay = new Date(); startOfDay.setHours(0, 0, 0, 0);
    const today = history.filter(h => h.t >= startOfDay.getTime());
    const recent = history.slice(0, 50);
    const byTarget = {};
    for (const h of today) byTarget[h.target] = (byTarget[h.target] || 0) + 1;
    let scanned = 0;
    const list = settings.watchers.map(w => {
        const rec = watchers.get(w.id);
        const st = rec && rec.status && now - rec.status.at < 5000 ? rec.status : null;
        if (rec && rec.status) scanned += rec.status.scanned;
        return {
            id: w.id, label: w.label, url: w.url, enabled: w.enabled, guildId: w.guildId, channelId: w.channelId,
            hasProfile: !!(w.sel || w.custom), sel: w.sel, custom: w.custom,
            state: !w.enabled ? 'off' : !rec ? 'starting' : !st ? 'starting' : !st.loggedIn ? 'login' : !st.ready ? 'loading' : 'live',
            lastMutationAgo: st && st.lastMutationAt ? Math.round((now - st.lastMutationAt) / 1000) : null,
            baselineCount: st ? st.baselineCount : 0, windowVisible: !!(rec && !rec.win.isDestroyed() && rec.win.isVisible())
        };
    });
    const safeSettings = JSON.parse(JSON.stringify(settings));
    safeSettings.alerts.webhookSet = !!settings.alerts.webhookUrl; safeSettings.alerts.webhookUrl = '';
    return {
        version: pkg.version, platform: process.platform, settings: safeSettings, watchers: list,
        lock: { left: gate.lockLeft(now), pausedLeft: gate.pausedLeft(now), total: settings.rules.joinLockMs },
        stats: {
            today: today.length, total: history.length, scanned, uptimeSec: Math.round((now - rt.startedAt) / 1000), byTarget,
            avgMs: recent.length ? Math.round(recent.reduce((a, h) => a + h.totalMs, 0) / recent.length * 10) / 10 : null,
            bestMs: recent.length ? Math.min(...recent.map(h => h.totalMs)) : null
        },
        last: rt.last, feed: rt.feed.slice(0, 30), clock: { state: rt.clockState, skewMs: Math.round(rt.skewMs) },
        webhookStatus: rt.webhookStatus, hasLast: !!rt.lastProto
    };
}
let stateTimer = null;
function scheduleState() { if (stateTimer) return; stateTimer = setTimeout(() => { stateTimer = null; send(control, 'state', snapshot()); refreshTray(); }, 120); }
function send(win, ch, data) { try { if (win && !win.isDestroyed()) win.webContents.send(ch, data); } catch (_) {} }

function applySettings(next, opts = {}) {
    const prevWatchers = JSON.stringify(settings.watchers.map(w => [w.id, w.url, w.enabled, w.label]));
    const prevMode = settings.windowMode;
    settings = next;
    if (opts.keepWebhook !== undefined && !settings.alerts.webhookUrl) settings.alerts.webhookUrl = opts.keepWebhook;
    if (prevWatchers !== JSON.stringify(settings.watchers.map(w => [w.id, w.url, w.enabled, w.label]))) ensureWatcherWindows();
    if (prevMode !== settings.windowMode) for (const rec of watchers.values()) applyWindowMode(rec.win);
    app.setLoginItemSettings({ openAtLogin: settings.app.openAtLogin });
    registerHotkeys(); broadcastCfg(); saveSoon(); scheduleState();
}

const analyzerFor = wid => { const w = settings.watchers.find(x => x.id === wid); return core.makeAnalyzer(core.effectiveConfig(settings, w, 0, true)); };

ipcMain.handle('state:get', () => snapshot());
ipcMain.handle('catalog', () => ({
    groups: E.GROUPS, presets: E.PRESETS.map(p => ({ id: p.id, name: p.name, ids: p.ids })),
    biomes: E.BIOMES.map(b => ({ id: b.id, g: b.g, name: b.name, pri: b.pri, merchant: b.merchant === true }))
}));
ipcMain.handle('settings:patch', (_e, patch) => {
    if (!patch || typeof patch !== 'object') return snapshot();
    const keep = settings.alerts.webhookUrl;
    const next = core.applyPatch(settings, patch);
    if (!(patch.alerts && typeof patch.alerts.webhookUrl === 'string')) next.alerts.webhookUrl = keep;
    applySettings(next);
    return snapshot();
});
ipcMain.handle('watcher:add', (_e, { input, label } = {}) => {
    const parsed = core.parseChannelInput(input);
    if (!parsed) return { error: 'Paste the channel link (right-click the channel → Copy Link) or type: serverID channelID. A channel ID alone is not enough for Discord to open a channel.' };
    if (settings.watchers.some(w => w.channelId === parsed.channelId)) return { error: 'That channel is already being watched.' };
    if (settings.watchers.length >= 3) return { error: 'You can watch up to 3 channels at once.' };
    applySettings(core.applyPatch(settings, { watchers: [...settings.watchers, { url: parsed.url, label }] }));
    return { ok: true };
});
ipcMain.handle('watcher:update', (_e, { id, label, enabled, sel, custom, clearProfile } = {}) => {
    const list = settings.watchers.map(w => {
        if (w.id !== id) return w;
        const n = { ...w };
        if (typeof label === 'string') n.label = label;
        if (typeof enabled === 'boolean') n.enabled = enabled;
        if (Array.isArray(sel)) n.sel = sel;
        if (Array.isArray(custom)) n.custom = custom;
        if (clearProfile) { n.sel = null; n.custom = null; }
        return n;
    });
    applySettings(core.applyPatch(settings, { watchers: list }));
    return snapshot();
});
ipcMain.handle('watcher:remove', (_e, id) => { applySettings(core.applyPatch(settings, { watchers: settings.watchers.filter(w => w.id !== id) })); return snapshot(); });
ipcMain.handle('window:open', (_e, id) => { openWatcherWindow(String(id)); return true; });
ipcMain.handle('lock:release', () => { gate.releaseLock(); scheduleState(); return true; });
ipcMain.handle('feed:open', (_e, id) => { const p = rt.protoById.get(Number(id)); if (!p) return false; gate.releaseLock(); return manualLaunch(p, 'Opened from activity'); });
ipcMain.handle('last:open', () => openLast());
ipcMain.handle('engine:test', (_e, { text, wid } = {}) => {
    const r = analyzerFor(wid).analyze(String(text || '').slice(0, 500));
    return { snipe: r.snipe, word: r.word, hits: r.hits.map(h => ({ word: h.word, negated: h.negated, why: h.why })) };
});
ipcMain.handle('selftest', () => {
    const a = core.makeAnalyzer({ selection: ['glitched', 'dreamspace', 'cyberspace', 'singularity', 'sinister', 'merchant_jester'], custom: [], typoMode: 'balanced', contextAI: true, extraIgnore: [] });
    const cases = [['glitch', 1], ['gLİTCHEDdd', 1], ['glicth', 1], ['cyber space', 1], ['dreamscape', 1], ['singu', 1], ['sinsstere', 1], ['dont miss glitch', 1], ['not fake glitch', 1], ['jester is here', 1],
        ['not cyber', 0], ['glitch ended', 0], ['fake dreamspace', 0], ['glitch too late', 0], ['no singularity', 0], ['jester has not arrived', 0], ['minister', 0], ['sister', 0], ['single', 0], ['hello', 0]];
    const failed = cases.filter(([t, ex]) => a.analyze(t).snipe !== !!ex).map(c => c[0]);
    return { total: cases.length, passed: cases.length - failed.length, failed };
});
ipcMain.handle('launch:test', () => shell.openExternal('roblox://').then(() => true).catch(() => false));
ipcMain.handle('webhook:test', async () => { await sendWebhook(null, true); return rt.webhookStatus; });
ipcMain.handle('history:get', () => history.slice(0, 200));
ipcMain.handle('history:clear', () => { history = []; saveSoon(); scheduleState(); return true; });
ipcMain.handle('signin:open', () => { openSignIn(); return true; });
ipcMain.handle('diagnostics', () => {
    const s = snapshot();
    return JSON.stringify({ version: pkg.version, electron: process.versions.electron, chrome: process.versions.chrome, platform: process.platform, clock: s.clock,
        watchers: s.watchers.map(w => ({ label: w.label, state: w.state, lastMutationAgo: w.lastMutationAgo, baseline: w.baselineCount })),
        rules: s.settings.rules, selection: settings.selection, custom: settings.custom, windowMode: settings.windowMode, stats: s.stats,
        feed: s.feed.slice(0, 12).map(f => f.kind + ' ' + f.text) }, null, 1);
});
ipcMain.handle('settings:export', () => { const c = JSON.parse(JSON.stringify(settings)); c.alerts.webhookUrl = ''; return JSON.stringify(c, null, 1); });
ipcMain.handle('settings:import', (_e, text) => {
    try { const raw = JSON.parse(String(text)); const keep = settings.alerts.webhookUrl; const next = core.sanitize(raw); next.alerts.webhookUrl = keep; applySettings(next); return { ok: true }; }
    catch (_) { return { error: 'That is not valid settings JSON.' }; }
});
ipcMain.handle('settings:reset', () => { const keep = settings.alerts.webhookUrl; const d = core.defaults(); d.watchers = settings.watchers; d.alerts.webhookUrl = keep; applySettings(core.sanitize(d)); return snapshot(); });
ipcMain.handle('app:quit', () => { app.quit(); });

function openLast() { if (!rt.lastProto) return false; gate.releaseLock(); return manualLaunch(rt.lastProto, 'Reopened last link'); }
function toggleEnabled() { applySettings(core.applyPatch(settings, { enabled: !settings.enabled })); }

// ---------------------------------------------------------------------------
// control centre, tray, hotkeys
// ---------------------------------------------------------------------------
function createControl() {
    control = new BrowserWindow({
        width: 1180, height: 780, minWidth: 980, minHeight: 640, show: false, backgroundColor: '#0a0e17', title: 'Madness BiomeSniperX', icon: ICON,
        titleBarStyle: 'hidden', titleBarOverlay: { color: '#0a0e17', symbolColor: '#cbd5e1', height: 44 },
        webPreferences: { preload: path.join(__dirname, 'ui-preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false }
    });
    control.setMenuBarVisibility(false);
    control.loadFile(path.join(__dirname, '..', 'ui', 'index.html'));
    control.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    control.webContents.on('will-navigate', ev => ev.preventDefault());
    control.once('ready-to-show', () => { if (!settings.app.startMinimized) control.show(); });
    control.on('close', ev => { if (!rt.quitting && settings.app.closeToTray) { ev.preventDefault(); control.hide(); } });
}
function showControl() { if (!control || control.isDestroyed()) createControl(); control.show(); control.focus(); }

function refreshTray() {
    if (!tray) return;
    tray.setContextMenu(Menu.buildFromTemplate([
        { label: 'Open Madness BiomeSniperX', click: showControl },
        { label: 'Sniper active', type: 'checkbox', checked: settings.enabled, click: toggleEnabled },
        { label: 'Release join lock', enabled: gate.lockLeft() > 0, click: () => { gate.releaseLock(); scheduleState(); } },
        { label: 'Open last link', enabled: !!rt.lastProto, click: openLast },
        { type: 'separator' },
        { label: 'Sign in to Discord…', click: openSignIn },
        { type: 'separator' },
        { label: 'Quit', click: () => app.quit() }
    ]));
}
function createTray() {
    tray = new Tray(nativeImage.createFromPath(ICON).resize({ width: 18, height: 18 }));
    tray.setToolTip('Madness BiomeSniperX');
    tray.on('click', showControl);
    refreshTray();
}

function registerHotkeys() {
    globalShortcut.unregisterAll();
    if (!settings.app.hotkeys) return;
    const reg = (acc, fn) => { try { globalShortcut.register(acc, fn); } catch (_) {} };
    reg('CommandOrControl+Alt+S', toggleEnabled);
    reg('CommandOrControl+Alt+L', () => { gate.releaseLock(); scheduleState(); });
    reg('CommandOrControl+Alt+O', openLast);
}

// ---------------------------------------------------------------------------
app.on('second-instance', showControl);
app.on('before-quit', () => { rt.quitting = true; writeJson('settings.json', settings); writeJson('history.json', history); });
app.on('will-quit', () => globalShortcut.unregisterAll());
app.on('window-all-closed', () => {});

app.whenReady().then(() => {
    settings = core.sanitize(readJson('settings.json', {}));
    history = (Array.isArray(readJson('history.json', [])) ? readJson('history.json', []) : []).filter(h => h && Number.isFinite(h.t)).slice(0, 300);
    const ses = session.fromPartition(PART);
    ses.setUserAgent(CHROME_UA);
    ses.setPermissionRequestHandler((_wc, permission, cb) => cb(['fullscreen', 'clipboard-sanitized-write'].includes(permission)));
    createControl(); createTray();
    ensureWatcherWindows();
    registerHotkeys();
    app.setLoginItemSettings({ openAtLogin: settings.app.openAtLogin });
    syncClock(); setInterval(syncClock, 20 * 60 * 1000);
    setInterval(scheduleState, 1000);          // keeps countdowns and health indicators fresh
});
